import { Routes, Route, useLocation } from "react-router-dom";

import Navbar from "./components/Navbar.jsx";
import Footer from "./components/Footer.jsx";

import Home from "./pages/Home.jsx";
import Services from "./pages/Services.jsx";
import Work from "./pages/Work.jsx";
import About from "./pages/About.jsx";
import Contact from "./pages/Contact.jsx";
import Portfolio from "./pages/Portfolio.jsx";

import PrivacyPolicy from "./pages/PrivacyPolicy.jsx";
import Terms from "./pages/Terms.jsx";
import RefundPolicy from "./pages/RefundPolicy.jsx";
import Support from "./pages/Support.jsx";

import Affiliate from "./pages/Affiliate.jsx";
import AffiliateForm from "./pages/AffiliateForm.jsx";

import OpenRoles from "./pages/OpenRoles.jsx";
import Culture from "./pages/Culture.jsx";

import AdminDashboard from "./pages/AdminDashboard.jsx";
import LoginForm from "./components/LoginForm.jsx";

import NotFound from "./pages/NotFound.jsx";

import ScrollToTop from "./components/ScrollToTop.jsx";
import FloatingCTA from "./components/FloatingCTA.jsx";
import InteractionManager from "./components/InteractionManager.jsx";

function App() {
  const location = useLocation();

  // Pages where Navbar/Footer/Floating CTA should be hidden
  const adminRoutes = [
    "/login",
    "/admindashboard",
  ];

  const isAdminPage = adminRoutes.includes(location.pathname);

  return (
    <>
      <InteractionManager />

      <a href="#main-content" className="skip-link">
        Skip to content
      </a>

      <ScrollToTop />

      {!isAdminPage && <Navbar />}

      <main role="main" id="main-content">
        <Routes>
          {/* Website Pages */}
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/work" element={<Work />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/portfolio" element={<Portfolio />} />

          {/* Legal Pages */}
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/refund" element={<RefundPolicy />} />
          <Route path="/support" element={<Support />} />

          {/* Affiliate */}
          <Route path="/affiliate" element={<Affiliate />} />
          <Route
            path="/affiliate/affiliateform"
            element={<AffiliateForm />}
          />

          {/* Careers */}
          <Route
            path="/careers/open-roles"
            element={<OpenRoles />}
          />
          <Route
            path="/careers/culture"
            element={<Culture />}
          />

          {/* Admin */}
          <Route path="/login" element={<LoginForm />} />
          <Route
            path="/admindashboard"
            element={<AdminDashboard />}
          />

          {/* 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      {!isAdminPage && <Footer />}
      {!isAdminPage && <FloatingCTA />}
    </>
  );
}

export default App;
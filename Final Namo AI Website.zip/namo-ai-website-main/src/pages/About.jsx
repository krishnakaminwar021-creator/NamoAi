import { useEffect } from "react";
import { Link } from "react-router-dom";
import { FaLinkedin } from "react-icons/fa";
import useSEO from "../hooks/useSEO";
import "./About.css";

/* =========================
   CORE PILLARS
========================= */
const pillars = [
  {
    n: "01",
    t: "Creativity",
    d: "Premium design, compelling content, and visual storytelling that captures attention and builds brand equity."
  },
  {
    n: "02",
    t: "Strategy",
    d: "Data-driven planning, market analysis, and structured execution frameworks that drive measurable results."
  },
  {
    n: "03",
    t: "Technology",
    d: "Modern development stacks, scalable architecture, and digital systems engineered for performance."
  }
];

/* =========================
   FOUNDERS
========================= */
const team = [
  { n: "Sarthak Fatale", r: "Founder & CEO", linkedin: "https://www.linkedin.com/in/sarthakfatale19/" },
  { n: "Prathmesh Sawarkar", r: "Co-Founder & CTO", linkedin: "https://www.linkedin.com/in/prathmesh-sawarkar-4a03b2362?utm_source=share_via&utm_content=profile&utm_medium=member_android" },
  { n: "Mangesh Dhamke", r: "Co-Founder & COO", linkedin: "https://www.linkedin.com/in/mangesh-dhamke-39102a390?utm_source=share_via&utm_content=profile&utm_medium=member_android" },
];

/* =========================
   LEADERSHIP TEAM (NEW)
========================= */
const leadershipTeam = [
  {
    n: "Krushna Kaminwar",
    r: "Managing Director",
    linkedin: "https://www.linkedin.com/in/krushna-kaminwar-90b575340/",
  },
  {
    n: "Purva Gharapurkar",
    r: "Head of Creative Department & HR",
    linkedin: "https://www.linkedin.com/in/purva-gharapurkar-b847b8337/",
  },
  {
    n: "Vedika Suryawanshi",
    r: "Head of Marketing Department & HR",
    linkedin: "https://www.linkedin.com/in/vedika-suryawanshi-861505329/",
  },
  {
    n: "Arjun Jadhav",
    r: "Head of Product & Development Department",
    linkedin: "https://www.linkedin.com/in/arjun-jadhav-358665340/",
  },
  {
    n: "Adarsh Bharti",
    r: "Head of Client Success Department",
    linkedin: "https://www.linkedin.com/in/adarsh-bharati-0b7b2a30b/",
  },
  {
    n: "Sachin Chaudhary",
    r: "Head of Project Execution Department",
    linkedin: "https://www.linkedin.com/in/sachin-choudhary-34353438b/",
  },
  {
    n: "Shivam Kalaskar",
    r: "Business Development & Marketing Specialist",
    linkedin: "https://www.linkedin.com/in/shivam-kalaskar/",
  },
  {
    n: "NETWORK",
    type: "stats",
  },
];
/* =========================
   DEPARTMENTS
========================= */
const departments = [
  {
    name: "Marketing Team",
    desc: "Growth strategy, SEO, paid media, and performance marketing.",
    icon: (
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M11 5h8M11 9h8M11 13h8M11 17h8M3 5h4v4H3zM3 13h4v4H3z" />
      </svg>
    )
  },
  {
    name: "Creative Team",
    desc: "Branding, graphic design, video editing, and content creation.",
    icon: (
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5">
        <circle cx="12" cy="12" r="9" />
        <circle cx="12" cy="12" r="5" />
      </svg>
    )
  },
  {
    name: "Development Team",
    desc: "Web development, app development, and technical systems.",
    icon: (
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5">
        <polyline points="16 18 22 12 16 6" />
        <polyline points="8 6 2 12 8 18" />
      </svg>
    )
  },
  {
    name: "Operations Team",
    desc: "Project management, client relations, and quality assurance.",
    icon: (
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
      </svg>
    )
  }
];

/* =========================
   COMPONENT
========================= */
export default function About() {

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) e.target.classList.add("revealed");
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -50px 0px" }
    );

    document.querySelectorAll(".reveal").forEach((el) =>
      observer.observe(el)
    );

    return () => observer.disconnect();
  }, []);

  useSEO({
    title: "About Us - Who We Are & Our Vision",
    description: "Learn about NamoAI Digital, a team of passionate digital creators, engineers, and marketers building the future of AI-driven digital solutions.",
    keywords: "About NamoAI Digital, startup story, development agency team, founders, business growth experts"
  });

  return (
    <div className="about-page page-transition-wrapper">

      {/* ===== HEADER ===== */}
      <section className="page-header">
        <div className="grid-bg" />
        <div className="container">
          <span className="section-label">About Us</span>
          <h1>
            Structured Execution. <span className="text-gradient">Scalable Growth.</span>
          </h1>
          <p>
            NAMO AI Digital Private Limited is a DPIIT-recognized startup empowering businesses with cutting-edge digital solutions. From web and app development to AI, automation, and digital marketing, we help brands build, grow, and scale in the digital era. Driven by innovation and results, we transform ideas into powerful digital experiences. 🚀
          </p>
        </div>
      </section>

      {/* ===== STORY ===== */}
      <section className="section">
        <div className="container about-story reveal-stagger">
          <div className="reveal">
            <span className="section-label">Our Philosophy</span>
            <h2 className="section-title">System over chaos. Execution over ideas.</h2>
          </div>

          <div className="about-story-body reveal">
            <p>
              NAMOAI Digital was founded on a clear philosophy: system over chaos, execution over ideas, and growth through structure.
            </p>
            <p>
              From content creation, branding, and development — we are a full-stack digital growth partner.
            </p>
          </div>
        </div>
      </section>

      {/* ===== PILLARS ===== */}
      <section className="section divider-top">
        <div className="container process-grid reveal-stagger">
          <div className="reveal">
            <span className="section-label">Core Pillars</span>
            <h2 className="section-title">Three pillars. <span className="muted">One vision.</span></h2>
          </div>

          <div className="process-list">
            {pillars.map((p) => (
              <div key={p.n} className="process-row reveal">
                <div className="mono-tiny">{p.n}</div>
                <div className="process-title">{p.t}</div>
                <div className="muted">{p.d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FOUNDERS ===== */}
      <section className="section divider-top">
        <div className="container reveal-stagger">

          <span className="section-label reveal">The Founders</span>

          <h2 className="section-title reveal" style={{ marginBottom: 48 }}>
            Founding Team
          </h2>

          <div className="team-grid">
            {team.map((m) => (
              <a
                key={m.n}
                href={m.linkedin}
                target="_blank"
                rel="noreferrer"
                className="team-card reveal"
                aria-label="Visit LinkedIn profile"
              >

                <div className="team-avatar">
                  <span>{m.n.charAt(0)}</span>
                </div>

                <div className="team-name">{m.n}</div>

                <div className="muted" style={{ fontSize: 13 }}>
                  {m.r}
                </div>

                <div className="linkedin-icon">
                  <FaLinkedin />
                </div>

              </a>
            ))}
          </div>
        </div>
      </section>

     
   {/* ===== LEADERSHIP TEAM ===== */}
<section className="section divider-top">
  <div className="container reveal-stagger">

    <span className="section-label reveal">Leadership</span>

    <h2
      className="section-title reveal"
      style={{ marginBottom: 48 }}
    >
     The Leadership Team
    </h2>

    <div className="leadership-grid">
      {leadershipTeam.map((m) => (
        m.type === "stats" ? (
          <div key={m.n || "network"} className="leadership-card reveal">

            <div className="leadership-stats">

              <div className="stats-header">
                🚀 Our Network
              </div>

              <div className="stats-grid">

                <div className="stat-item">
                  <div className="stat-number">50+</div>
                  <div className="stat-label">Developers</div>
                </div>

                <div className="stat-item">
                  <div className="stat-number">100+</div>
                  <div className="stat-label">Editors</div>
                </div>

                <div className="stat-item">
                  <div className="stat-number">20+</div>
                  <div className="stat-label">Marketing Pros</div>
                </div>

                <div className="stat-item">
                  <div className="stat-number">25+</div>
                  <div className="stat-label">Partners</div>
                </div>

              </div>

            </div>

          </div>
        ) : (
          <a
            key={m.n}
            href={m.linkedin}
            target="_blank"
            rel="noreferrer"
            className="leadership-card reveal"
            aria-label="Visit LinkedIn profile"
          >
            <div className="leadership-avatar">
              <span>{m.n.charAt(0)}</span>
            </div>

            <div className="team-name">
              {m.n}
            </div>

            <div
              className="muted"
              style={{ fontSize: 13 }}
            >
              {m.r}
            </div>

            <div className="linkedin-icon">
              <FaLinkedin />
            </div>
          </a>
        )
      ))}
    </div>

  </div>
</section>
      {/* ===== DEPARTMENTS ===== */}
      <section className="section divider-top">
        <div className="container reveal-stagger">

          <span className="section-label reveal">Departments</span>

          <h2 className="section-title reveal" style={{ marginBottom: 48 }}>
            Structured capability.
          </h2>

          <div className="dept-grid">
            {departments.map((dept) => (
              <div key={dept.name} className="dept-card reveal">
                <div className="dept-icon">{dept.icon}</div>
                <h3>{dept.name}</h3>
                <p>{dept.desc}</p>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* ===== CTA ===== */}
      <section className="section divider-top" style={{ textAlign: "center" }}>
        <div className="container reveal">
          <h2 className="section-title">Let's build something serious.</h2>
          <Link to="/contact" className="btn btn-primary" style={{ marginTop: 32 }}>
            Start Your Project →
          </Link>
        </div>
      </section>

    </div>
  );
}

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import logo from "../assets/logo.png";
const API_URL = import.meta.env.VITE_API_URL;
import "./AdminDashboard.css";

// ─────────────────────────────────────────────────────────────────────────────
// MOCK DATA — Replace these with API calls when backend is ready
// e.g. const res = await fetch("${API_URL}/api/stats"); const data = await res.json();
// ─────────────────────────────────────────────────────────────────────────────

const STATS = {
  totalClients: 25,
  totalProjects: 18,
  activeProjects: 12,
  completedProjects: 6,
};
 
// Future: GET ${API_URL}/api/services/stats
const SERVICES = [
  {
    id: 1,
    name: "Web & App Development",
    icon: "🌐",
    color: "indigo",
    total: 5,
    active: 3,
    completed: 2,
  },
  {
    id: 2,
    name: "AI Automation Solutions",
    icon: "🤖",
    color: "cyan",
    total: 2,
    active: 1,
    completed: 1,
  },
  {
    id: 3,
    name: "Business Growth & Consulting",
    icon: "📈",
    color: "emerald",
    total: 3,
    active: 2,
    completed: 1,
  },
  {
    id: 4,
    name: "Performance Marketing",
    icon: "🎯",
    color: "amber",
    total: 4,
    active: 3,
    completed: 1,
  },
  {
    id: 5,
    name: "Digital Marketing",
    icon: "📣",
    color: "rose",
    total: 2,
    active: 1,
    completed: 1,
  },
  {
    id: 6,
    name: "Creative Branding Services",
    icon: "✦",
    color: "violet",
    total: 2,
    active: 2,
    completed: 0,
  },
];

// ─────────────────────────────────────────────────────────────────────────────
// ICONS
// ─────────────────────────────────────────────────────────────────────────────

const Icon = ({ name, size = 18 }) => {
  const s = { width: size, height: size };
  const icons = {
    dashboard: (
      <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7" rx="1.5" />
        <rect x="14" y="3" width="7" height="7" rx="1.5" />
        <rect x="3" y="14" width="7" height="7" rx="1.5" />
        <rect x="14" y="14" width="7" height="7" rx="1.5" />
      </svg>
    ),
    clients: (
      <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    ),
    projects: (
      <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
      </svg>
    ),
    logout: (
      <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
        <polyline points="16 17 21 12 16 7" />
        <line x1="21" y1="12" x2="9" y2="12" />
      </svg>
    ),
    menu: (
      <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="3" y1="6" x2="21" y2="6" />
        <line x1="3" y1="12" x2="21" y2="12" />
        <line x1="3" y1="18" x2="21" y2="18" />
      </svg>
    ),
    close: (
      <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="18" y1="6" x2="6" y2="18" />
        <line x1="6" y1="6" x2="18" y2="18" />
      </svg>
    ),
    bell: (
      <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
        <path d="M13.73 21a2 2 0 0 1-3.46 0" />
      </svg>
    ),
    check: (
      <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="20 6 9 17 4 12" />
      </svg>
    ),
    active: (
      <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" />
        <polyline points="12 6 12 12 16 14" />
      </svg>
    ),
  };
  return icons[name] || null;
};

// ─────────────────────────────────────────────────────────────────────────────
// STAT CARD
// ─────────────────────────────────────────────────────────────────────────────

function StatCard({ icon, label, value, color, trend }) {
  return (
    <div className={`stat-card stat-${color}`}>
      <div className="stat-glow" />
      <div className="stat-icon-wrap">
        <Icon name={icon} size={20} />
      </div>
      <div className="stat-body">
        <span className="stat-value">{value}</span>
        <span className="stat-label">{label}</span>
      </div>
      
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SERVICE CARD — dynamically rendered
// Future: data comes from GET ${API_URL}/api/services/:id/stats
// ─────────────────────────────────────────────────────────────────────────────

function ServiceCard({ service }) {
  return (
    <div className={`service-card service-${service.color}`}>
      <div className="service-card-top">
        <span className="service-icon">
          {service.icon}
        </span>

        <div
          className={`service-tag service-tag-${service.color}`}
        >
          {service.active} active
        </div>
      </div>

      <h3 className="service-name">
        {service.name}
      </h3>

      <div className="service-stats">
        <div className="service-stat">
          <span className="sstat-val">
            {service.total}
          </span>
          <span className="sstat-lbl">
            Total
          </span>
        </div>

        <div className="service-stat-divider" />

        <div className="service-stat">
          <span className="sstat-val sstat-active">
            {service.active}
          </span>
          <span className="sstat-lbl">
            Active
          </span>
        </div>

        <div className="service-stat-divider" />

        <div className="service-stat">
          <span className="sstat-val sstat-done">
            {service.completed}
          </span>
          <span className="sstat-lbl">
            Done
          </span>
        </div>
      </div>
    </div>
  );
}
// ─────────────────────────────────────────────────────────────────────────────
// DASHBOARD SECTION
// ─────────────────────────────────────────────────────────────────────────────

function DashboardSection() {
  const [admin, setAdmin] = useState(null);

  const [stats, setStats] = useState({
    totalClients: 0,
    totalProjects: 0,
    activeProjects: 0,
    completedProjects: 0,
  });

  const [services, setServices] = useState([]);

  useEffect(() => {
    const stored = localStorage.getItem("admin");

    if (!stored || stored === "undefined") return;

    try {
      setAdmin(JSON.parse(stored));
    } catch (err) {
      console.log("Invalid admin data", err);
    }

    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch(
        `${API_URL}/api/dashboard`
      );

      const data = await response.json();

      if (data.success) {
        setStats(data.stats);
        setServices(data.services);
      }
    } catch (error) {
      console.log(error);
    }
  };
  const serviceMeta = {
  "Web & App Development": {
    icon: "🌐",
    color: "indigo",
  },
  "AI Automation Solutions": {
    icon: "🤖",
    color: "cyan",
  },
  "Business Growth & Consulting": {
    icon: "📈",
    color: "emerald",
  },
  "Performance Marketing": {
    icon: "🎯",
    color: "amber",
  },
  "Digital Marketing": {
    icon: "📣",
    color: "rose",
  },
  "Creative Branding Services": {
    icon: "✦",
    color: "violet",
  },
};

  return (
    <div className="section">
      <div className="section-eyebrow">Overview</div>

      <h2 className="section-title">
        Dashboard
      </h2>

      <p className="section-sub">
        Welcome back,
        <strong> {admin?.name}</strong>
        {" "}— here's your agency at a glance.
      </p>

      {/* SAME UI */}
      <div className="top-stats-grid">
        <StatCard
          icon="clients"
          label="Total Clients"
          value={stats.totalClients}
          color="indigo"
        />

        <StatCard
          icon="projects"
          label="Total Projects"
          value={stats.totalProjects}
          color="cyan"
        />

        <StatCard
          icon="active"
          label="Active Projects"
          value={stats.activeProjects}
          color="emerald"
        />

        <StatCard
          icon="check"
          label="Completed Projects"
          value={stats.completedProjects}
          color="violet"
        />
      </div>

      <div className="services-heading-row">
        <div>
          <div className="section-eyebrow">
            Breakdown
          </div>

          <h3 className="services-title">
            Projects by Service
          </h3>
        </div>

        <span className="services-count">
          {services.length} services
        </span>
      </div>

      {/* SAME UI */}
   <div className="services-grid">
  {services.map((service, index) => {
    const meta = serviceMeta[service.name] || {
      icon: "📁",
      color: "indigo",
    };

    return (
      <ServiceCard
        key={index}
        service={{
          ...service,
          icon: meta.icon,
          color: meta.color,
        }}
      />
    );
  })}
</div>
    </div>
  );
}
// ─────────────────────────────────────────────────────────────────────────────
// CLIENTS SECTION (stub — ready for API)
// Future: GET ${API_URL}/api/clients
// ─────────────────────────────────────────────────────────────────────────────
function ClientsSection() {
  const [clients, setClients] = useState([]);
const [loading, setLoading] = useState(false);

const [form, setForm] = useState({
   clientName: "",
  companyName: "",
  email: "",
  phone: "",
  serviceType: "",

  projectName: "",
  startDate: "",
  deadline: "",
});
// ADD THIS HERE ↓↓↓
  useEffect(() => {
    fetchClients();
  }, []);

  const fetchClients = async () => {
    try {
      const response = await fetch(`${API_URL}/api/clients`);
      const data = await response.json();

      if (data.success) {
        setClients(data.clients);
      }
    } catch (error) {
      console.log(error);
    }
  };


  const addClient = async () => {
  if (
 !form.clientName ||
  !form.email ||
  !form.serviceType ||
  !form.projectName ||
  !form.startDate ||
  !form.deadline
  ) {
    alert("Please fill required fields");
    return;
  }

  try {
    setLoading(true);

    const response = await fetch(
      `${API_URL}/api/clients`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
         client_name: form.clientName,
  company_name: form.companyName,
  email: form.email,
  phone: form.phone,
  service_type: form.serviceType,

  project_name: form.projectName,
  start_date: form.startDate,
  deadline: form.deadline,
        }),
      }
    );

    const data = await response.json();

    if (!data.success) {
      alert(data.message);
      return;
    }

  await fetchClients();

setForm({
 clientName: "",
  companyName: "",
  email: "",
  phone: "",
  serviceType: "",

  projectName: "",
  startDate: "",
  deadline: "",
});

    alert("Client added successfully ✅");
  } catch (error) {
    console.log(error);
    alert("Server Error");
  } finally {
    setLoading(false);
  }
};

const deleteClient = async (id) => {

  const confirmDelete = window.confirm(
    "Are you sure you want to delete this client?"
  );

  if (!confirmDelete) return;

  try {

    const response = await fetch(
      `${API_URL}/api/clients/${id}`,
      {
        method: "DELETE",
      }
    );

    const data = await response.json();

    if (!data.success) {
      alert(data.message);
      return;
    }

    setClients(
      clients.filter((client) => client.id !== id)
    );

    alert("Client deleted successfully ✅");

  } catch (error) {
    console.log(error);
    alert("Server Error");
  }
};

  return (
    <div className="section">
      <div className="section-eyebrow">Directory</div>
      <h2 className="section-title">Clients</h2>

      <div className="client-form-card">
        <h3>Add Client</h3>

        <input
          placeholder="Client Name"
          value={form.clientName}
          onChange={(e) =>
            setForm({
              ...form,
              clientName: e.target.value,
            })
          }
        />

        <input
          placeholder="Company Name"
          value={form.companyName}
          onChange={(e) =>
            setForm({
              ...form,
              companyName: e.target.value,
            })
          }
        />

        <input
          placeholder="Email"
          value={form.email}
          onChange={(e) =>
            setForm({
              ...form,
              email: e.target.value,
            })
          }
        />

        <input
          placeholder="Phone"
          value={form.phone}
          onChange={(e) =>
            setForm({
              ...form,
              phone: e.target.value,
            })
          }
        />

        <select
          value={form.serviceType}
          onChange={(e) =>
            setForm({
              ...form,
              serviceType: e.target.value,
            })
          }
        >
          <option value="">
            Select Service
          </option>

          <option>
            Web & App Development
          </option>

          <option>
            AI Automation Solutions
          </option>

          <option>
            Business Growth & Consulting
          </option>

          <option>
            Performance Marketing
          </option>

          <option>
            Digital Marketing
          </option>

          <option>
            Creative Branding Services
          </option>
        </select>

        <input
  placeholder="Project Name"
  value={form.projectName}
  onChange={(e) =>
    setForm({
      ...form,
      projectName: e.target.value,
    })
  }
/>

<label>Project Start Date</label>
<input
  type="date"
  value={form.startDate}
  onChange={(e) =>
    setForm({
      ...form,
      startDate: e.target.value,
    })
  }
/>

<label>Project Deadline</label>
<input
  type="date"
  value={form.deadline}
  onChange={(e) =>
    setForm({
      ...form,
      deadline: e.target.value,
    })
  }
/>

     <button onClick={addClient}>
  Add Client
</button>
      </div>

      <div className="client-table-card">
        <table>
          <thead>
            <tr>
              <th>Client</th>
              <th>Company</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Service</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {clients.map((client) => (
              <tr key={client.id}>
                   <td>{client.client_name}</td>
      <td>{client.company_name}</td>
      <td>{client.email}</td>
      <td>{client.phone}</td>
      <td>{client.service_type}</td>
                <td>
                 <button
  onClick={() => deleteClient(client.id)}
>
  Delete
</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PROJECTS SECTION (stub — ready for API)
// Future: GET ${API_URL}/api/projects
// ─────────────────────────────────────────────────────────────────────────────

function ProjectsSection() {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await fetch(
        `${API_URL}/api/projects`
      );

      const data = await response.json();

      if (data.success) {
        setProjects(data.projects);
      }
    } catch (error) {
      console.log(error);
    }
  };
 const updateStatus = async (id) => {

  const confirmUpdate = window.confirm(
    "Mark this project as completed?"
  );

  if (!confirmUpdate) return;

  try {
    const response = await fetch(
      `${API_URL}/api/projects/${id}/status`,
      {
        method: "PUT",
      }
    );

    const data = await response.json();

    if (data.success) {
      fetchProjects();
      alert("Project marked as completed ✅");
    }

  } catch (error) {
    console.log(error);
  }
};

const ongoingProjects = projects.filter(
  (project) => project.status === "active"
);

const completedProjects = projects.filter(
  (project) => project.status === "completed"
);
    
 return (
  <div className="section">
    <div className="section-eyebrow">
      Pipeline
    </div>

    <h2 className="section-title">
      Projects
    </h2>

    <h3>Ongoing Projects</h3>

    <div className="client-table-card">
      <table>
        <thead>
          <tr>
            <th>Company</th>
            <th>Project</th>
            <th>Service</th>
            <th>Status</th>
            <th>Start Date</th>
            <th>Deadline</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {ongoingProjects.length === 0 ? (
            <tr>
              <td colSpan="7">
                No Ongoing Projects
              </td>
            </tr>
          ) : (
            ongoingProjects.map((project) => (
              <tr key={project.id}>
                <td>{project.company_name}</td>

                <td>{project.project_name}</td>

                <td>{project.service_type}</td>

                <td>{project.status}</td>

                <td>
                  {project.start_date
                    ? project.start_date.slice(0, 10)
                    : "-"}
                </td>

                <td>
                  {project.deadline
                    ? project.deadline.slice(0, 10)
                    : "-"}
                </td>

                <td>
                  <button
                    onClick={() =>
                      updateStatus(project.id)
                    }
                  >
                    Mark Completed
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>

    <h3 style={{ marginTop: "30px" }}>
      Completed Projects
    </h3>

    <div className="client-table-card">
      <table>
        <thead>
          <tr>
            <th>Company</th>
            <th>Project</th>
            <th>Service</th>
            <th>Status</th>
            <th>Start Date</th>
            <th>Deadline</th>
          </tr>
        </thead>

        <tbody>
          {completedProjects.length === 0 ? (
            <tr>
              <td colSpan="6">
                No Completed Projects
              </td>
            </tr>
          ) : (
            completedProjects.map((project) => (
              <tr key={project.id}>
                <td>{project.company_name}</td>

                <td>{project.project_name}</td>

                <td>{project.service_type}</td>

                <td>✅ Completed</td>

                <td>
                  {project.start_date
                    ? project.start_date.slice(0, 10)
                    : "-"}
                </td>

                <td>
                  {project.deadline
                    ? project.deadline.slice(0, 10)
                    : "-"}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  </div>
);
}
// ─────────────────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────────────

const NAV = [
  { id: "dashboard", label: "Dashboard", icon: "dashboard" },
  { id: "clients",   label: "Clients",   icon: "clients"   },
  { id: "projects",  label: "Projects",  icon: "projects"  },
];

export default function AdminDashboard() {
  const [active, setActive]       = useState("dashboard");
  const [sideOpen, setSideOpen]   = useState(false);

  const SECTIONS = {
    dashboard: <DashboardSection />,
    clients:   <ClientsSection />,
    projects:  <ProjectsSection />,
  };

 const navigate = useNavigate();

  const handleLogout = () => {
    const confirmLogout = window.confirm(
      "Are you sure you want to logout?"
    );

    if (!confirmLogout) return;

    localStorage.removeItem("admin");
    localStorage.removeItem("token");

    navigate("/");
  };

  return (
   <div className="admin-dashboard-root">
      {/* ── Mobile overlay ── */}
      {sideOpen && (
        <div className="sidebar-overlay" onClick={() => setSideOpen(false)} />
      )}

      {/* ── Sidebar ── */}
      <aside className={`sidebar ${sideOpen ? "sidebar-open" : ""}`}>
        {/* Aurora glow decoration */}
        <div className="sidebar-aurora" />

        <div className="sidebar-logo">
          <img src={logo} alt="NAMO AI" className="logo" />
          <div className="logo-text-wrap">
            <span className="brand-text">
              NAMO<span className="brand-dim"> AI DIGITAL</span>
            </span>
          </div>
        </div>

        <nav className="sidebar-nav">
          {NAV.map(item => (
            <button
              key={item.id}
              className={`nav-item ${active === item.id ? "nav-active" : ""}`}
              onClick={() => { setActive(item.id); setSideOpen(false); }}
            >
              <span className="nav-icon"><Icon name={item.icon} size={17} /></span>
              <span className="nav-label">{item.label}</span>
              {active === item.id && <span className="nav-pip" />}
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-user">
            <div className="user-avatar">A</div>
            <div className="user-info">
              <span className="user-name">NAMOAI Admin</span>
              <span className="user-role">Super Admin</span>
            </div>
          </div>
          <button
  className="logout-btn"
  onClick={handleLogout}
>
  Logout
</button>
        </div>
      </aside>

      {/* ── Main ── */}
      <div className="main">
        {/* Topbar */}
        <header className="topbar">
          <button className="hamburger" onClick={() => setSideOpen(!sideOpen)}>
            <Icon name={sideOpen ? "close" : "menu"} size={21} />
          </button>
          <div className="topbar-brand">
            <span className="topbar-name">NAMOAI</span>
            <span className="topbar-sep">/</span>
            <span className="topbar-page">
              {NAV.find(n => n.id === active)?.label}
            </span>
          </div>
          <div className="topbar-right">
            
            <div className="topbar-avatar">A</div>
          </div>
        </header>

        {/* Content */}
        <main className="content">
          {SECTIONS[active]}
        </main>
      </div>
    </div>
  );
}

import React from "react";
import "./Legal.css";
import { Link } from "react-router-dom";

export default function Affiliate() {
  return (
    <div className="legal-page">
      {/* ── Hero ── */}
      <section className="legal-hero">
        <h1>
          Affiliate <span className="text-gradient">Program</span>
        </h1>
        <p className="legal-subtitle">
          Partner with NAMOAI Digital, help businesses grow, and earn rewards.
        </p>
        <span className="legal-effective-date">DPIIT Recognized Startup</span>
      </section>

      {/* ── Content ── */}
      <div className="legal-content-wrapper">
        {/* Section 01 — Introduction */}
        <section className="legal-section">
          <span className="legal-section-number">Section 01</span>
          <h2>Welcome to the NAMOAI Digital Affiliate Program</h2>
          <p>
            We believe in building strong partnerships that create value for everyone involved.
            Whether you are a freelancer, digital marketer, agency owner, influencer, student,
            consultant, or business professional, our Affiliate Program allows you to earn commissions
            by referring clients to our services.
          </p>
          <p>
            When your referral becomes a paying client, you earn a commission on the successful sale.
            Our program is built on mutual trust, transparency, and a shared goal of delivering
            outstanding digital results.
          </p>
        </section>

        {/* Section 02 — Why Join */}
        <section className="legal-section">
          <span className="legal-section-number">Section 02</span>
          <h2>Why Join the NAMOAI Digital Affiliate Program?</h2>
          <div className="legal-cards-grid">
            <div className="legal-card">
              <div className="legal-card-icon">💰</div>
              <h3>Attractive Commissions</h3>
              <p>Earn competitive commissions for every successful client referral you make.</p>
            </div>
            <div className="legal-card">
              <div className="legal-card-icon">🚀</div>
              <h3>Unlimited Potential</h3>
              <p>There is no limit to the number of clients you can refer or the amount you can earn.</p>
            </div>
            <div className="legal-card">
              <div className="legal-card-icon">🆓</div>
              <h3>No Registration Fee</h3>
              <p>Joining our affiliate network is completely free of charge for all partners.</p>
            </div>
            <div className="legal-card">
              <div className="legal-card-icon">💼</div>
              <h3>Wide Range of Services</h3>
              <p>Promote world-class digital solutions that modern businesses actively need.</p>
            </div>
            <div className="legal-card">
              <div className="legal-card-icon">🤝</div>
              <h3>Dedicated Support</h3>
              <p>Receive marketing assistance, promotional materials, and guidance from our team.</p>
            </div>
            <div className="legal-card">
              <div className="legal-card-icon">💎</div>
              <h3>Trusted Brand</h3>
              <p>Partner with a DPIIT Recognized Startup focused on delivering measurable business growth.</p>
            </div>
          </div>
        </section>

        {/* Section 03 — Eligible Services */}
        <section className="legal-section">
          <span className="legal-section-number">Section 03</span>
          <h2>Services Eligible for Affiliate Commission</h2>
          <p>
            You can earn commissions by referring clients for any of NAMOAI Digital's core services:
          </p>
          <ul>
            <li><strong>Website Development</strong> &amp; <strong>E-Commerce Website Development</strong></li>
            <li><strong>Mobile App Development</strong> &amp; <strong>Software Development</strong></li>
            <li><strong>Custom Business Solutions</strong> &amp; <strong>AI Chatbot Development</strong></li>
            <li><strong>Digital Marketing Services</strong>, <strong>SEO</strong>, &amp; <strong>Social Media Marketing</strong></li>
            <li><strong>Branding &amp; Graphic Design</strong></li>
            <li><strong>WhatsApp Automation</strong> &amp; <strong>Cloud Solutions</strong></li>
            <li><strong>Business Consulting</strong> &amp; <strong>Maintenance &amp; Support Services</strong></li>
          </ul>
          <p className="muted" style={{ fontSize: "14px", marginTop: "12px" }}>
            * Additional service categories may be added to this list from time to time.
          </p>
        </section>

        {/* Section 04 — How It Works */}
        <section className="legal-section">
          <span className="legal-section-number">Section 04</span>
          <h2>How the Affiliate Program Works</h2>
          <ol>
            <li>
              <strong>Register</strong> — Complete the Affiliate Registration Form and submit your application.
            </li>
            <li>
              <strong>Approval</strong> — Our team reviews your application and activates your affiliate account.
            </li>
            <li>
              <strong>Refer Clients</strong> — Share NAMOAI Digital services through your network, website, social media, email campaigns, business contacts, or professional referrals.
            </li>
            <li>
              <strong>Client Conversion</strong> — When your referred client purchases a service and completes payment, the referral is verified.
            </li>
            <li>
              <strong>Earn Commission</strong> — Once payment verification is completed, your commission becomes eligible for payout.
            </li>
          </ol>
        </section>

        {/* Section 05 — Commission Structure */}
        <section className="legal-section">
          <span className="legal-section-number">Section 05</span>
          <h2>Commission Structure</h2>
          <p>
            Affiliate commissions are calculated and awarded based on:
          </p>
          <ul>
            <li>Service Type and Scope</li>
            <li>Total Project Value</li>
            <li>Contract Duration</li>
            <li>Subscription Plans</li>
            <li>Special Promotional Campaigns</li>
          </ul>
          <div className="legal-note">
            <strong>📌 Note:</strong> Commission percentages vary depending on the project and service category. Detailed, project-specific commission structures will be shared in detail with approved affiliates upon account activation.
          </div>
        </section>

        {/* Section 06 — Responsibilities */}
        <section className="legal-section">
          <span className="legal-section-number">Section 06</span>
          <h2>Affiliate Responsibilities</h2>
          <p>As an approved affiliate partner, you are expected to:</p>
          <ul>
            <li>Promote NAMOAI Digital services professionally, honestly, and ethically.</li>
            <li>Provide accurate, up-to-date information regarding our services and capabilities.</li>
            <li>Maintain complete transparency with potential clients regarding your affiliate relation.</li>
            <li>Comply with all local, national, and international laws and regulations.</li>
            <li>Protect the reputation, brand integrity, and image of NAMOAI Digital.</li>
          </ul>
        </section>

        {/* Section 07 — Prohibited Activities */}
        <section className="legal-section">
          <span className="legal-section-number">Section 07</span>
          <h2>Prohibited Activities</h2>
          <p>Affiliates are strictly prohibited from engaging in the following actions:</p>
          <ul>
            <li>Making false promises, unrealistic claims, or unauthorized guarantees.</li>
            <li>Misrepresenting service pricing, timelines, features, or deliverables.</li>
            <li>Engaging in spam marketing, unsolicited emailing, or invasive communication.</li>
            <li>Using deceptive, fraudulent, or misleading advertising practices.</li>
            <li>Creating fake leads, self-referrals, or fraudulent user accounts.</li>
            <li>Using unauthorized NAMOAI Digital branding assets or design materials.</li>
            <li>Bidding on NAMOAI Digital trademarks or search terms in paid advertising without prior written consent.</li>
          </ul>
          <div className="legal-warning">
            <strong>⚠️ Warning:</strong> Any violation of the prohibited activities will result in immediate termination of the affiliate account and forfeiture of all pending commissions.
          </div>
        </section>

        {/* Section 08 — Referral Validation */}
        <section className="legal-section">
          <span className="legal-section-number">Section 08</span>
          <h2>Referral Validation</h2>
          <p>A referral is considered validated only when the following conditions are met:</p>
          <ul>
            <li>The referral was generated directly by the affiliate's tracked link or code.</li>
            <li>The referred client is new to NAMOAI Digital and is not an existing or past customer.</li>
            <li>The client successfully purchases an eligible service.</li>
            <li>All associated payments have been received and verified in full by NAMOAI Digital.</li>
          </ul>
          <p>
            The Company reserves the sole and final right of decision regarding referral ownership and validation.
          </p>
        </section>

        {/* Section 09 — Commission Payments */}
        <section className="legal-section">
          <span className="legal-section-number">Section 09</span>
          <h2>Commission Payments</h2>
          <p>
            <strong>Payment Schedule:</strong> Validated affiliate commissions are generally processed and paid within <strong>15–30 business days</strong> after successful client payment verification.
          </p>
          <p>
            <strong>Payment Methods:</strong> Commissions are disbursed via approved channels including direct bank transfer, UPI, or other mutually agreed payment methods. Affiliates are responsible for providing correct and active payment details.
          </p>
        </section>

        {/* Section 10 — Refunds & Commission Reversal */}
        <section className="legal-section">
          <span className="legal-section-number">Section 10</span>
          <h2>Refunds and Commission Reversal</h2>
          <p>
            If a referred client's payment is refunded, reversed, charged back, or determined to be fraudulent:
          </p>
          <ul>
            <li>The corresponding affiliate commission will be cancelled or reversed.</li>
            <li>If the commission has already been paid, the amount will be adjusted/deducted from the affiliate's future payouts or recovered directly.</li>
          </ul>
        </section>

        {/* Section 11 — Intellectual Property */}
        <section className="legal-section">
          <span className="legal-section-number">Section 11</span>
          <h2>Intellectual Property</h2>
          <p>
            All trademarks, logos, branding assets, marketing materials, website content, and designs remain the exclusive property of NAMOAI Digital Private Limited.
          </p>
          <p>
            Affiliates are granted a limited, revocable license to use approved promotional materials solely for authorized marketing purposes under this program.
          </p>
        </section>

        {/* Section 12 — Program Modification */}
        <section className="legal-section">
          <span className="legal-section-number">Section 12</span>
          <h2>Program Modification</h2>
          <p>
            NAMOAI Digital Private Limited reserves the right to modify commission structures, update affiliate policies, introduce new service categories, or suspend/discontinue the program at any time. Reasonable notice will be provided to active affiliates whenever possible.
          </p>
        </section>

        {/* Section 13 — Termination */}
        <section className="legal-section">
          <span className="legal-section-number">Section 13</span>
          <h2>Termination</h2>
          <p>
            Affiliate accounts may be suspended or terminated immediately if terms are violated, fraudulent activity is detected, misleading promotions are identified, or if the affiliate acts in a way that damages NAMOAI Digital's brand or reputation. Upon termination, unpaid commissions associated with policy violations are forfeited.
          </p>
        </section>

        {/* Section 14 — Limitation of Liability */}
        <section className="legal-section">
          <span className="legal-section-number">Section 14</span>
          <h2>Limitation of Liability</h2>
          <p>
            NAMOAI Digital Private Limited shall not be liable for any indirect, incidental, special, or consequential damages arising from your participation in the Affiliate Program. Participation is completely voluntary and at the affiliate's own risk.
          </p>
        </section>

        {/* Section 15 — Contact Us */}
        <section className="legal-section">
          <span className="legal-section-number">Section 15</span>
          <h2>Contact Us</h2>
          <p>
            For affiliate support, partnership opportunities, or commission-related queries, please contact us:
          </p>
          <div className="support-info-row">
            <div className="support-info-item">
              <span className="info-label">Email</span> <br />
              <span className="info-value">digitalnamoai@gmail.com</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">Website</span> <br />
              <span className="info-value">www.namoaidigital.in</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">Company</span> <br />
              <span className="info-value">NAMOAI Digital Private Limited</span>
            </div>
          </div>
        </section>
        
      </div>
      <div className="application-redirect"> <Link to="/affiliate/affiliateform" className="affiliate-submit-btn">
              Fill Our Form
            </Link>
</div>
       
         
      {/* ── Contact CTA ── */}
      <section className="legal-contact-cta">
        <h2>Ready to Start Earning?</h2>
        <p>
          Join the NAMOAI Digital Affiliate Program today and help businesses grow while creating a new source of income for yourself.
        </p>
        <div className="legal-contact-links">
          <a href="mailto:digitalnamoai@gmail.com">✉️ Email Us</a>
          <a href="https://www.namoaidigital.in" target="_blank" rel="noopener noreferrer">🌐 Visit Website</a>
        </div>
      </section>
    </div>
  );
}

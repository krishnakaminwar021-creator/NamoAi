import "./Legal.css";
import { useState, useRef } from "react";

const MANDATORY_FIELDS = {
  fullName: "Full Name",
  dob: "Date of Birth",
  gender: "Gender",
  email: "Email",
  mobile: "Mobile",
  city: "City",
  occupation: "Occupation",
  company: "Company",
  experience: "Experience",
  reason: "Why Join?",
  agreeTerms: "Terms & Conditions",
};

export default function AffiliateForm() {
  const url =
    "https://script.google.com/macros/s/AKfycbza-ZC3RHlKvZqCV1FZNm5J9wWvzMoXayxLspXDOw67P6RowMmV7fjpsw-8wgiOt90mhQ/exec";

  const [formData, setFormData] = useState({});
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitAttempted, setSubmitAttempted] = useState(false);
  const topBannerRef = useRef(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      if (name === "agreeTerms") {
        setFormData((prev) => ({ ...prev, [name]: checked }));
      } else {
        setFormData((prev) => ({
          ...prev,
          services: { ...prev.services, [name]: checked },
        }));
      }
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
    if (errors[name]) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy[name];
        return copy;
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};

    // Full Name
    if (!formData.fullName || !formData.fullName.trim()) {
      newErrors.fullName = "Full Name is required";
    } else if (formData.fullName.trim().length < 2) {
      newErrors.fullName = "Full Name must be at least 2 characters";
    } else if (!/^[a-zA-Z\s'-]+$/.test(formData.fullName.trim())) {
      newErrors.fullName = "Full Name can only contain letters, spaces, hyphens, and apostrophes";
    }

    // Date of Birth
    if (!formData.dob) {
      newErrors.dob = "Date of Birth is required";
    } else {
      const dob = new Date(formData.dob);
      const today = new Date();
      const minAge = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
      const maxAge = new Date(today.getFullYear() - 100, today.getMonth(), today.getDate());
      if (isNaN(dob.getTime())) {
        newErrors.dob = "Please enter a valid Date of Birth";
      } else if (dob > minAge) {
        newErrors.dob = "You must be at least 18 years old";
      } else if (dob < maxAge) {
        newErrors.dob = "Please enter a valid Date of Birth";
      }
    }

    // Gender
    if (!formData.gender || formData.gender === "") {
      newErrors.gender = "Gender is required";
    }

    // Email
    if (!formData.email || !formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address";
    }

    // Mobile
    if (!formData.mobile || !formData.mobile.trim()) {
      newErrors.mobile = "Mobile number is required";
    } else if (!/^[+]?[0-9\s-]{10,15}$/.test(formData.mobile)) {
      newErrors.mobile = "Please enter a valid phone number (10–15 digits)";
    }

    // WhatsApp (optional)
    if (formData.whatsapp && formData.whatsapp.trim()) {
      if (!/^[+]?[0-9\s-]{10,15}$/.test(formData.whatsapp.trim())) {
        newErrors.whatsapp = "Please enter a valid WhatsApp number (10–15 digits)";
      }
    }

    // City
    if (!formData.city || !formData.city.trim()) {
      newErrors.city = "City is required";
    } else if (!/^[a-zA-Z\s'.-]+$/.test(formData.city.trim())) {
      newErrors.city = "City name can only contain letters, spaces, and hyphens";
    }

    // State (optional)
    if (formData.state && formData.state.trim()) {
      if (!/^[a-zA-Z\s'.-]+$/.test(formData.state.trim())) {
        newErrors.state = "State name can only contain letters, spaces, and hyphens";
      }
    }

    // Country (optional)
    if (formData.country && formData.country.trim()) {
      if (!/^[a-zA-Z\s'.-]+$/.test(formData.country.trim())) {
        newErrors.country = "Country name can only contain letters, spaces, and hyphens";
      }
    }

    // LinkedIn (optional)
    if (formData.linkedin && formData.linkedin.trim()) {
      try {
        const u = new URL(formData.linkedin.trim());
        if (!u.hostname.includes("linkedin.com")) {
          newErrors.linkedin = "Please enter a valid LinkedIn URL";
        }
      } catch {
        newErrors.linkedin = "Please enter a valid LinkedIn URL";
      }
    }

    // Instagram (optional)
    if (formData.instagram && formData.instagram.trim()) {
      try {
        const u = new URL(formData.instagram.trim());
        if (!u.hostname.includes("instagram.com")) {
          newErrors.instagram = "Please enter a valid Instagram URL";
        }
      } catch {
        newErrors.instagram = "Please enter a valid Instagram URL";
      }
    }

    // Occupation
    if (!formData.occupation || formData.occupation === "") {
      newErrors.occupation = "Occupation is required";
    }

    // Company
    if (!formData.company || !formData.company.trim()) {
      newErrors.company = "Company is required";
    } else if (formData.company.trim().length < 2) {
      newErrors.company = "Company name must be at least 2 characters";
    }

    // Expertise (optional)
    if (formData.expertise && formData.expertise.trim().length > 200) {
      newErrors.expertise = "Expertise must be under 200 characters";
    }

    // Experience
    if (!formData.experience || !formData.experience.trim()) {
      newErrors.experience = "Experience is required";
    } else if (formData.experience.trim().length > 200) {
      newErrors.experience = "Experience must be under 200 characters";
    }

    // Why Join
    if (!formData.reason || !formData.reason.trim()) {
      newErrors.reason = "Please tell us why you want to join";
    } else if (formData.reason.trim().length < 10) {
      newErrors.reason = "Please elaborate a bit more (at least 10 characters)";
    } else if (formData.reason.trim().length > 1000) {
      newErrors.reason = "Response must be under 1000 characters";
    }

    // Promotion (optional)
    if (formData.promotion && formData.promotion.trim().length > 200) {
      newErrors.promotion = "Promotion method must be under 200 characters";
    }

    // Referrals (optional)
    if (formData.referrals && formData.referrals.trim()) {
      const n = Number(formData.referrals.trim());
      if (isNaN(n) || !Number.isInteger(n) || n < 0) {
        newErrors.referrals = "Please enter a valid whole number (0 or more)";
      }
    }

    // Referral Code (optional)
    if (formData.referralCode && formData.referralCode.trim()) {
      if (!/^[a-zA-Z0-9_-]{3,20}$/.test(formData.referralCode.trim())) {
        newErrors.referralCode = "Referral code must be 3–20 alphanumeric characters";
      }
    }

    // Terms
    if (!formData.agreeTerms) {
      newErrors.agreeTerms = "You must agree to the Terms & Conditions";
    }

    setErrors(newErrors);
    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitAttempted(true);
    const newErrors = validateForm();
    if (Object.keys(newErrors).length > 0) {
      setTimeout(() => {
        topBannerRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 50);
      return;
    }
    setIsSubmitting(true);
    try {
      const res = await fetch(url, { method: "POST", body: JSON.stringify(formData) });
      const text = await res.text();
      console.log(text);
      alert("Form Submitted Successfully!");
      setFormData({});
      setErrors({});
      setSubmitAttempted(false);
    } catch (err) {
      console.log(err);
      alert("Error submitting form");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Split errors: missing mandatory vs format errors
  const missingMandatory = Object.keys(errors).filter((k) => k in MANDATORY_FIELDS);
  const formatErrors = Object.entries(errors).filter(([k]) => !(k in MANDATORY_FIELDS));
  const hasErrors = Object.keys(errors).length > 0;

  // Red asterisk — forced red via style tag to beat any CSS specificity
  const REQ = (
    <span style={{
      color: "#ef4444",
      fontSize: "14px",
      fontWeight: 700,
      marginLeft: "3px",
      lineHeight: 1,
      display: "inline",
      WebkitTextFillColor: "#ef4444",
    }}>*</span>
  );

  return (
    <>
      {/* Inject a style tag so .req-star is ALWAYS red regardless of CSS cascade */}
      <style>{`.req-star { color: #ef4444 !important; -webkit-text-fill-color: #ef4444 !important; }`}</style>

      <section className="affiliate-form-section">
        <div className="affiliate-form-container">

          {/* ── TOP BANNER: shown above the form after first failed submit ── */}
          {submitAttempted && hasErrors && (
            <div
              ref={topBannerRef}
              role="alert"
              aria-live="assertive"
              style={{
                marginBottom: "24px",
                background: "linear-gradient(135deg, rgba(239,68,68,0.12), rgba(239,68,68,0.06))",
                border: "1px solid rgba(239,68,68,0.4)",
                borderLeft: "4px solid #ef4444",
                borderRadius: "14px",
                padding: "16px 20px",
                backdropFilter: "blur(12px)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "10px" }}>
                <span style={{ fontSize: "16px" }}>⚠️</span>
                <p style={{ margin: 0, fontWeight: 700, fontSize: "13px", color: "#fca5a5" }}>
                  Please complete all required fields before submitting:
                </p>
              </div>
              {missingMandatory.length > 0 && (
                <ul style={{ margin: "0 0 8px 0", paddingLeft: "20px", fontSize: "12.5px", color: "#fca5a5", lineHeight: 1.9 }}>
                  {missingMandatory.map((key) => (
                    <li key={key}>
                      <strong>{MANDATORY_FIELDS[key]}</strong> — {errors[key]}
                    </li>
                  ))}
                </ul>
              )}
              {formatErrors.length > 0 && (
                <>
                  <p style={{ margin: "6px 0 4px 0", fontWeight: 600, fontSize: "12.5px", color: "#fca5a5" }}>
                    Fix the following:
                  </p>
                  <ul style={{ margin: 0, paddingLeft: "20px", fontSize: "12.5px", color: "#fca5a5", lineHeight: 1.9 }}>
                    {formatErrors.map(([key, msg]) => (
                      <li key={key}>{msg}</li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          )}

          <form className="affiliate-form-grid" onSubmit={handleSubmit}>

            {/* PERSONAL */}
            <div className="form-group">
              <label>Full Name <span className="req-star">*</span></label>
              <input name="fullName" type="text" value={formData.fullName || ""} onChange={handleChange} className={errors.fullName ? "error-input" : ""} />
              {errors.fullName && <span className="error-message">{errors.fullName}</span>}
            </div>

            <div className="form-group">
              <label>Date of Birth <span className="req-star">*</span></label>
              <input name="dob" type="date" value={formData.dob || ""} onChange={handleChange} className={errors.dob ? "error-input" : ""} />
              {errors.dob && <span className="error-message">{errors.dob}</span>}
            </div>

            <div className="form-group">
              <label>Gender <span className="req-star">*</span></label>
              <select name="gender" value={formData.gender || ""} onChange={handleChange} className={errors.gender ? "error-input" : ""}>
                <option value="">Select</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
              </select>
              {errors.gender && <span className="error-message">{errors.gender}</span>}
            </div>

            <div className="form-group">
              <label>Email <span className="req-star">*</span></label>
              <input name="email" type="email" value={formData.email || ""} onChange={handleChange} className={errors.email ? "error-input" : ""} />
              {errors.email && <span className="error-message">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label>Mobile <span className="req-star">*</span></label>
              <input name="mobile" type="tel" value={formData.mobile || ""} onChange={handleChange} className={errors.mobile ? "error-input" : ""} />
              {errors.mobile && <span className="error-message">{errors.mobile}</span>}
            </div>

            <div className="form-group">
              <label>WhatsApp</label>
              <input name="whatsapp" type="tel" value={formData.whatsapp || ""} onChange={handleChange} className={errors.whatsapp ? "error-input" : ""} />
              {errors.whatsapp && <span className="error-message">{errors.whatsapp}</span>}
            </div>

            <div className="form-group">
              <label>City <span className="req-star">*</span></label>
              <input name="city" type="text" value={formData.city || ""} onChange={handleChange} className={errors.city ? "error-input" : ""} />
              {errors.city && <span className="error-message">{errors.city}</span>}
            </div>

            <div className="form-group">
              <label>State</label>
              <input name="state" type="text" value={formData.state || ""} onChange={handleChange} className={errors.state ? "error-input" : ""} />
              {errors.state && <span className="error-message">{errors.state}</span>}
            </div>

            <div className="form-group">
              <label>Country</label>
              <input name="country" type="text" value={formData.country || ""} onChange={handleChange} className={errors.country ? "error-input" : ""} />
              {errors.country && <span className="error-message">{errors.country}</span>}
            </div>

            <div className="form-group">
              <label>LinkedIn</label>
              <input name="linkedin" type="url" value={formData.linkedin || ""} onChange={handleChange} className={errors.linkedin ? "error-input" : ""} />
              {errors.linkedin && <span className="error-message">{errors.linkedin}</span>}
            </div>

            <div className="form-group">
              <label>Instagram</label>
              <input name="instagram" type="url" value={formData.instagram || ""} onChange={handleChange} className={errors.instagram ? "error-input" : ""} />
              {errors.instagram && <span className="error-message">{errors.instagram}</span>}
            </div>

            {/* PROFESSIONAL */}
            <div className="form-group">
              <label>Occupation <span className="req-star">*</span></label>
              <select name="occupation" value={formData.occupation || ""} onChange={handleChange} className={errors.occupation ? "error-input" : ""}>
                <option value="">Select</option>
                <option>Student</option>
                <option>Freelancer</option>
                <option>Business Owner</option>
                <option>Influencer</option>
              </select>
              {errors.occupation && <span className="error-message">{errors.occupation}</span>}
            </div>

            <div className="form-group">
              <label>Company <span className="req-star">*</span></label>
              <input name="company" type="text" value={formData.company || ""} onChange={handleChange} className={errors.company ? "error-input" : ""} />
              {errors.company && <span className="error-message">{errors.company}</span>}
            </div>

            <div className="form-group">
              <label>Expertise</label>
              <input name="expertise" type="text" value={formData.expertise || ""} onChange={handleChange} className={errors.expertise ? "error-input" : ""} />
              {errors.expertise && <span className="error-message">{errors.expertise}</span>}
            </div>

            <div className="form-group">
              <label>Experience <span className="req-star">*</span></label>
              <input name="experience" type="text" value={formData.experience || ""} onChange={handleChange} className={errors.experience ? "error-input" : ""} />
              {errors.experience && <span className="error-message">{errors.experience}</span>}
            </div>

            <div className="form-group">
              <label>Why join? <span className="req-star">*</span></label>
              <textarea name="reason" value={formData.reason || ""} onChange={handleChange} className={errors.reason ? "error-input" : ""}></textarea>
              {errors.reason && <span className="error-message">{errors.reason}</span>}
            </div>

            <div className="form-group">
              <label>Promotion Method</label>
              <input name="promotion" value={formData.promotion || ""} onChange={handleChange} className={errors.promotion ? "error-input" : ""} />
              {errors.promotion && <span className="error-message">{errors.promotion}</span>}
            </div>

            <div className="form-group">
              <label>Referrals/month</label>
              <input name="referrals" value={formData.referrals || ""} onChange={handleChange} className={errors.referrals ? "error-input" : ""} />
              {errors.referrals && <span className="error-message">{errors.referrals}</span>}
            </div>

            <div className="form-group">
              <label>Referral Code</label>
              <input name="referralCode" value={formData.referralCode || ""} onChange={handleChange} className={errors.referralCode ? "error-input" : ""} />
              {errors.referralCode && <span className="error-message">{errors.referralCode}</span>}
            </div>

            <div className="form-group checkbox-group">
              <label className="checkbox-label">
                <input type="checkbox" name="agreeTerms" checked={!!formData.agreeTerms} onChange={handleChange} />
                <span>I agree to the Terms &amp; Conditions and Privacy Policy <span className="req-star">*</span></span>
              </label>
              {errors.agreeTerms && <span className="error-message">{errors.agreeTerms}</span>}
            </div>

            {/* ── WARNING STRIP just above the Submit button ── */}
            {submitAttempted && hasErrors && (
              <div
                style={{
                  gridColumn: "1 / -1",
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "10px",
                  background: "rgba(239,68,68,0.10)",
                  border: "1px solid rgba(239,68,68,0.35)",
                  borderRadius: "12px",
                  padding: "12px 16px",
                }}
              >
                <span style={{ fontSize: "16px", flexShrink: 0, marginTop: "1px" }}>⚠️</span>
                <div>
                  <p style={{ margin: "0 0 4px 0", fontWeight: 700, fontSize: "12.5px", color: "#fca5a5" }}>
                    {Object.keys(errors).length} field{Object.keys(errors).length > 1 ? "s" : ""} need{Object.keys(errors).length === 1 ? "s" : ""} attention:
                  </p>
                  <p style={{ margin: 0, fontSize: "12px", color: "rgba(252,165,165,0.85)", lineHeight: 1.6 }}>
                    {missingMandatory.map((k) => MANDATORY_FIELDS[k]).join(", ")}
                    {missingMandatory.length > 0 && formatErrors.length > 0 ? " — and fix format errors above." : missingMandatory.length > 0 ? " — please fill these required fields." : "Please fix the format errors highlighted above."}
                  </p>
                </div>
              </div>
            )}

            <div className="affiliate-submit-wrap" style={{ gridColumn: "1 / -1" }}>
              <button type="submit" className="affiliate-submit-btn" disabled={isSubmitting}>
                {isSubmitting ? (
                  <><span className="spinner" /> Submitting...</>
                ) : (
                  "Submit Application"
                )}
              </button>
            </div>

          </form>
        </div>
      </section>
    </>
  );
}

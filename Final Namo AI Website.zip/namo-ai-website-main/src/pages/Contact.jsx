import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import "./Contact.css";

const serviceOptions = [
  "Website Development",
  "App Development",
  "Branding",
  "Digital Marketing",
  "Video Editing",
  "Graphic Design",
  "SEO",
  "Other",
];

export default function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    company: "",
    budget: "Select Budget Range",
    message: "",
  });

  const location = useLocation();
  const [selectedServices, setSelectedServices] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // ─── Scroll to form if hash matches ───────────────────────────────────────
  useEffect(() => {
    if (location.hash === "#contact-form" || location.hash === "#project-form") {
      setTimeout(() => {
        const el =
          document.getElementById("contact-form") ||
          document.getElementById("project-form");
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 300);
    }
  }, [location]);

  // ─── Intersection observer for .reveal elements ────────────────────────────
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) e.target.classList.add("revealed");
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -50px 0px" }
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  // ─── Lock scroll when modal is visible ────────────────────────────────────
  useEffect(() => {
    document.body.style.overflow = showSuccessModal ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [showSuccessModal]);



  // ─── Helpers ──────────────────────────────────────────────────────────────
  const update = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const toggleService = (svc) => {
    if (submitting) return;
    setSelectedServices((prev) =>
      prev.includes(svc) ? prev.filter((s) => s !== svc) : [...prev, svc]
    );
  };

  // ─── Step 1 → 2 → 3: Submit form ──────────────────────────────────────────
  const submit = (e) => {
    e.preventDefault();
    if (submitting) return;
    if (!form.name || !form.email || !form.message) return;

    setSubmitting(true);

    const servicesText =
      selectedServices.length > 0
        ? selectedServices.join(", ")
        : "None specified";

    const text = `Hello NAMOAI DIGITAL PRIVATE LIMITED Team!

I'm interested in working with you.

Name: ${form.name}
Email: ${form.email}
Company: ${form.company || "Not specified"}

Services Needed:
${servicesText}

Budget:
${form.budget}

Requirements:
${form.message}
`;

    const whatsappURL = `https://wa.me/919579057085?text=${encodeURIComponent(text)}`;

    // ─── Step 2: Show success modal immediately ────────────────────────────
    setShowSuccessModal(true);

    // ─── Step 3: Open WhatsApp in a new tab ───────────────────────────────
    window.open(whatsappURL, "_blank", "noopener,noreferrer");

    // ─── Step 4 → 5: When user comes back to this tab → redirect to Calendly
    const handleReturn = () => {
      if (document.visibilityState === "visible") {
        document.removeEventListener("visibilitychange", handleReturn);
        setTimeout(() => {
          window.location.href = "https://calendly.com/namoai-team";
        }, 1500);
      }
    };

    document.addEventListener("visibilitychange", handleReturn);
  };

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div>
      {/* ── Page header ─────────────────────────────────────────────────── */}
      <section className="page-header">
        <div className="grid-bg" />
        <div className="container">
          <span className="section-label">Contact</span>
          <h1>
            Let's <span className="text-gradient">build.</span>
          </h1>
          <p>
            Tell us about your business goals, project requirements and digital
            growth plans. Our team typically responds within one business day.
          </p>
        </div>
      </section>

      {/* ── Contact section ─────────────────────────────────────────────── */}
      <section className="section">
        <div className="container contact-grid reveal-stagger">

          {/* ── Form ─────────────────────────────────────────────────────── */}
          <form
            id="contact-form"
            className="contact-form glass reveal"
            onSubmit={submit}
          >
            <h2>Start your project with us</h2>
            <p className="muted" style={{ marginBottom: "28px" }}>
              Websites, apps, branding, marketing, content creation &amp; more.
            </p>

            {/* Name + Email */}
            <div className="field-row">
              <div className="field">
                <label htmlFor="contact-name">Name</label>
                <input
                  id="contact-name"
                  required
                  disabled={submitting}
                  value={form.name}
                  onChange={update("name")}
                  placeholder="Your name"
                />
              </div>
              <div className="field">
                <label htmlFor="contact-email">Email</label>
                <input
                  id="contact-email"
                  required
                  disabled={submitting}
                  type="email"
                  value={form.email}
                  onChange={update("email")}
                  placeholder="you@company.com"
                />
              </div>
            </div>

            {/* Company */}
            <div className="field">
              <label htmlFor="contact-company">Company</label>
              <input
                id="contact-company"
                disabled={submitting}
                value={form.company}
                onChange={update("company")}
                placeholder="Company / Brand name"
              />
            </div>

            {/* Services */}
            <div className="field">
              <label id="services-label" style={{ marginBottom: "12px" }}>
                Services Needed
              </label>
              <div
                className="service-tags-wrap"
                role="group"
                aria-labelledby="services-label"
              >
                {serviceOptions.map((svc) => (
                  <span
                    key={svc}
                    role="checkbox"
                    aria-checked={selectedServices.includes(svc)}
                    tabIndex={0}
                    className={`service-tag ${
                      selectedServices.includes(svc) ? "selected" : ""
                    } ${submitting ? "disabled" : ""}`}
                    onClick={() => toggleService(svc)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        toggleService(svc);
                      }
                    }}
                  >
                    {svc}
                  </span>
                ))}
              </div>
            </div>

            {/* Budget */}
            <div className="field">
              <label htmlFor="contact-budget">Est. Budget Range</label>
              <select
                id="contact-budget"
                className="select-field"
                disabled={submitting}
                value={form.budget}
                onChange={update("budget")}
              >
                <option disabled value="Select Budget Range">
                  Select Budget Range
                </option>
                <option value="Under ₹50k">Under ₹50,000</option>
                <option value="₹50k - ₹1.5L">₹50,000 – ₹1,50,000</option>
                <option value="₹1.5L - ₹3L">₹1,50,000 – ₹3,00,000</option>
                <option value="₹3L+">₹3,00,000+</option>
              </select>
            </div>

            {/* Message */}
            <div className="field">
              <label htmlFor="contact-message">
                Tell us about your project
              </label>
              <textarea
                id="contact-message"
                rows={5}
                required
                disabled={submitting}
                value={form.message}
                onChange={update("message")}
                placeholder="Describe your requirements, goals, timeline and services you need..."
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="btn btn-primary submit-btn-loading-wrap"
              style={{ marginTop: "12px" }}
              disabled={submitting}
            >
              {submitting ? (
                <>
                  <span className="submit-btn-spinner" />
                  Sending…
                </>
              ) : (
                "Send message →"
              )}
            </button>
          </form>

          {/* ── Sidebar ──────────────────────────────────────────────────── */}
          <aside className="contact-side reveal">
              <a
  href="https://mail.google.com/mail/?view=cm&fs=1&to=namoaidigital09@gmail.com"
  target="_blank"
  rel="noopener noreferrer"
  className="contact-card glass"
  aria-label="Send email to NAMOAI Digital"
>
  <div className="contact-icon">✉</div>

  <div>
    <div className="mono-tiny">Email</div>

    <div className="contact-value">
      digitalnamoai@gmail.com
    </div>
  </div>
</a>

            <a
              href="https://wa.me/919579057085"
              target="_blank"
              rel="noreferrer"
              className="contact-card glass"
            >
              <div className="contact-icon">☎</div>
              <div>
                <div className="mono-tiny">WhatsApp</div>
                <div className="contact-value">+91 95790 57085</div>
              </div>
            </a>

            <div className="contact-card glass" style={{ display: "block" }}>
              <div className="mono-tiny" style={{ marginBottom: "8px" }}>
                Services
              </div>
              <div style={{ fontWeight: 500 }}>
                Web Development, App Development, Branding, Marketing &amp;
                Content Creation
              </div>
              <div className="muted" style={{ fontSize: "14px", marginTop: "8px" }}>
                250+ projects completed across multiple industries.
              </div>
            </div>

            <div className="contact-card glass" style={{ display: "block" }}>
              <div className="mono-tiny" style={{ marginBottom: "8px" }}>
                Registered Office
              </div>
              <div style={{ fontWeight: 500 }}>
                NAMOAI DIGITAL PRIVATE LIMITED
              </div>
              <div className="muted" style={{ fontSize: "14px", marginTop: "4px" }}>
                Nanded, Maharashtra — 431604
              </div>
            </div>
          </aside>
        </div>
      </section>

      {/* ── Success Modal (shown during WhatsApp → Calendly transition) ──── */}
      <AnimatePresence>
        {showSuccessModal && (
          <motion.div
            className="contact-modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="contact-modal-card glass"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
            >
              <div className="contact-modal-glow" />

              {/* Check icon */}
              <div className="success-icon-wrap modal-success-icon-wrap">
                <div className="success-icon-ring" />
                <div className="success-icon">✓</div>
              </div>

              <h3 className="contact-modal-title">
                Thank You for Contacting NAMOAI Digital!
              </h3>

              <p className="contact-modal-message">
                Your inquiry has been prepared and sent via WhatsApp.
              </p>

              <p className="contact-modal-submessage muted">
                To help us understand your requirements better and provide the
                best solution, please schedule a free consultation call with our
                team.
              </p>

              <div className="contact-modal-divider" />

              {/* Progress flow — mirrors the diagram steps */}
              <div className="modal-progress-flow">
                {/* Step 1 ✓ */}
                <div className="progress-step-item completed">
                  <span className="step-badge-check">✓</span>
                  <span className="step-label-text">Contact Form Submitted</span>
                </div>

                {/* Step 2 ✓ */}
                <div className="progress-step-item completed">
                  <span className="step-badge-check">✓</span>
                  <span className="step-label-text">WhatsApp Message Prepared</span>
                </div>

                {/* Step 3 ✓ */}
                <div className="progress-step-item completed">
                  <span className="step-badge-check">✓</span>
                  <span className="step-label-text">WhatsApp Opened</span>
                </div>

                {/* Step 4 ✓ (user sent message and returned) */}
                <div className="progress-step-item completed">
                  <span className="step-badge-check">✓</span>
                  <span className="step-label-text">Message Sent on WhatsApp</span>
                </div>

                {/* Step 5 — active: redirecting to Calendly */}
                <div className="progress-step-item active">
                  <span className="step-badge-spinner">
                    <svg className="modal-spinner-svg" viewBox="0 0 50 50">
                      <circle
                        className="path"
                        cx="25"
                        cy="25"
                        r="20"
                        fill="none"
                        strokeWidth="5"
                      />
                    </svg>
                  </span>
                  <span className="step-label-text">
                    Redirecting to Free Consultation Booking
                  </span>
                </div>
              </div>

              <p className="contact-modal-redirect-hint">
                You will be redirected automatically in a few seconds…
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

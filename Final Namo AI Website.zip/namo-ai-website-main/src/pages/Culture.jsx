import { useEffect } from "react";
import { Link } from "react-router-dom";
import "./Culture.css";

const features = [
  {
    title: "Innovation at the Core",
    desc: "We push boundaries and explore new technologies daily. From integrating advanced AI models to designing automated marketing systems, we remain at the forefront of digital tools to deliver maximum value.",
    icon: "💡"
  },
  {
    title: "A Culture of Collaboration",
    desc: "We believe that great things are built together. Our development, creative, and marketing teams collaborate continuously, exchanging ideas, brainstorming strategies, and reviews to build high-quality solutions.",
    icon: "🤝"
  },
  {
    title: "Growth Without Limits",
    desc: "We support continuous learning. Whether it is mastering a new framework, acquiring a sales certification, or learning UI/UX, we offer the resources and mentorship required to help you grow.",
    icon: "📈"
  },
  {
    title: "Ownership and Accountability",
    desc: "At NAMOAI, you own your work. We give everyone the freedom to drive projects and make decisions, fostering accountability and developing the management skills necessary for leadership roles.",
    icon: "🔑"
  },
  {
    title: "People-First Philosophy",
    desc: "We care about the team's well-being. We maintain flexible working conditions, encourage open conversations about mental health, and provide a support structure where everyone feels heard and valued.",
    icon: "❤️"
  },
  {
    title: "Entrepreneurial Mindset",
    desc: "We encourage you to think like a founder. We value proactivity, creative problem solving, and building efficient workflows that reduce friction and systemize success.",
    icon: "🚀"
  },
  {
    title: "Excellence in Everything We Do",
    desc: "We hold ourselves to high standards of quality and execution. We pay close attention to visual details, code optimization, page speeds, and data analytics to ensure our clients receive elite results.",
    icon: "✨"
  },
  {
    title: "Life at NAMOAI Digital",
    desc: "Work is not just about tasks and deadlines. We celebrate milestones, coordinate team dinners, participate in learning bootcamps, and build a positive work environment where work feels rewarding.",
    icon: "🎉"
  }
];

export default function Culture() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("revealed");
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -50px 0px" }
    );

    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <div className="culture-page page-transition-wrapper">
      {/* Hero */}
      <section className="page-header">
        <div className="grid-bg" />
        <div className="container">
          <span className="section-label">Culture</span>
          <h1>
            Our <span className="text-gradient">Culture</span>
          </h1>
          <p className="hero-desc">
            Building a Workplace Where Innovation, Growth, and People Come First.
          </p>
        </div>
      </section>

      {/* Intro Section */}
      <section className="section">
        <div className="container about-story reveal-stagger">
          <div className="reveal">
            <span className="section-label">Who We Are</span>
            <h2 className="section-title">System over chaos. People over process.</h2>
          </div>

          <div className="about-story-body reveal">
            <p>
              NAMOAI Digital Private Limited is founded on a clear philosophy: progress over perfection, alignment over instruction, and execution over ideas. We aim to foster an entrepreneurial environment where everyone takes ownership and develops leadership skills.
            </p>
            <p>
              Working here means collaborating with passionate professionals to build systems that automate, scale, and deliver impact. We value integrity, curiosity, and a relentless drive to deliver quality.
            </p>
          </div>
        </div>
      </section>

      {/* Feature Sections (Alternating) */}
      <section className="section divider-top">
        <div className="container">
          <div className="section-head-center reveal" style={{ marginBottom: "64px" }}>
            <span className="section-label">Our Core Values</span>
            <h2 className="section-title text-center">What Defines Us</h2>
            <p className="section-subtext muted">
              The principles that guide our everyday interactions, work ethics, and project decisions.
            </p>
          </div>

          <div className="alternating-features">
            {features.map((feat, idx) => (
              <div
                key={idx}
                className={`feat-section reveal ${
                  idx % 2 === 1 ? "feat-section--reversed" : ""
                }`}
              >
                <div className="feat-icon-box glass">
                  <span className="feat-emoji">{feat.icon}</span>
                </div>
                <div className="feat-info">
                  <span className="mono-tiny">VALUE 0{idx + 1}</span>
                  <h3>{feat.title}</h3>
                  <p className="muted">{feat.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision Cards */}
      <section className="section divider-top">
        <div className="container mission-vision-grid reveal-stagger">
          <div className="mv-card glass reveal">
            <div className="mv-icon">🎯</div>
            <h2>Our Mission</h2>
            <p className="muted">
              To empower startups, enterprises, and modern brands with cutting-edge technology, creative designs, and performance-driven marketing systems to achieve scalable, systemized digital growth.
            </p>
          </div>

          <div className="mv-card glass reveal">
            <div className="mv-icon">👁️‍🗨️</div>
            <h2>Our Vision</h2>
            <p className="muted">
              To be a globally recognized digital growth agency, trusted for outstanding project execution, technical innovation, and cultivating high-impact leaders who drive digital transformation.
            </p>
          </div>
        </div>
      </section>

      {/* Join the Team Section */}
      <section className="section divider-top">
        <div className="container">
          <div className="cta-card reveal">
            <div className="ambient" />
            <div className="cta-inner">
              <span className="section-label">Grow With Us</span>
              <h2 className="section-title">Join a Team That Builds the Future</h2>
              
              <p className="cta-paragraph muted">
                We are always looking for passionate creators, developers, and builders who want to grow rapidly in a high-octane startup environment. Check out our open roles, and fill the form.
              </p>

              <div className="hero-cta" style={{ marginTop: 32 }}>
                <Link to="/careers/open-roles" className="btn btn-primary">
                  View Open Roles →
                </Link>
               
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

import { useEffect, useState, useRef } from "react";
import ServicePricingModal from "../components/ServicePricingModal";
import { Link } from "react-router-dom";
import TestimonialsCarsoule from "../components/TestimonialsCarsoule";
import Aurora from "../components/Aurora";
import useSEO from "../hooks/useSEO";
import "./Home.css";

// ===== Animated Counter =====
function AnimatedCounter({ value, duration = 1200, prefix = "", suffix = "" }) {
  const [count, setCount] = useState(0);
  const elementRef = useRef(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (!window.IntersectionObserver) {
      const cleanVal = String(value).replace(/[^0-9.]/g, "");
      setCount(parseFloat(cleanVal) || 0);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];

        if (entry.isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;

          const cleanVal = String(value).replace(/[^0-9.]/g, "");
          const target = parseFloat(cleanVal) || 0;

          if (target === 0) {
            setCount(0);
            return;
          }

          const isDecimal = String(value).includes(".");
          let startTime = null;

          const animate = (currentTime) => {
            if (!startTime) startTime = currentTime;
            const elapsedTime = currentTime - startTime;
            const progress = Math.min(elapsedTime / duration, 1);
            const easeProgress = progress * (2 - progress);
            const currentVal = easeProgress * target;

            if (isDecimal) {
              setCount(parseFloat(currentVal.toFixed(1)));
            } else {
              setCount(Math.floor(currentVal));
            }

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(target);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.15 }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => observer.disconnect();
  }, [value, duration]);

  return (
    <span ref={elementRef}>
      {prefix}
      {count}
      {suffix}
    </span>
  );
}

// ===== Data =====
const logos = [
  "Web Development",
  "Mobile Apps",
  "AI Automation",
  "Business Consulting",
  "Performance Marketing",
  "Digital Marketing",
  "Creative Branding",
];

const services = [
  {
    n: "01",
    t: "Web & App Development",
    d: "Custom websites, web applications, and mobile apps built for performance, scalability, and business growth.",
    icon: "💻",
    serviceKey: "webDevelopment",
  },
  {
    n: "02",
    t: "AI Automation Solutions",
    d: "Intelligent AI-powered systems that automate workflows, improve efficiency, and streamline business operations.",
    icon: "🤖",
    serviceKey: "aiAutomation",
  },
  {
    n: "03",
    t: "Business Growth & Consulting",
    d: "Strategic consulting and growth-focused solutions designed to help startups and businesses scale effectively.",
    icon: "📊",
    serviceKey: "consulting",
  },
  {
    n: "04",
    t: "Performance Marketing",
    d: "Data-driven advertising campaigns focused on lead generation, conversions, and measurable ROI.",
    icon: "🚀",
    serviceKey: "performanceMarketing",
  },
  {
    n: "05",
    t: "Digital Marketing",
    d: "Comprehensive digital marketing strategies including SEO, social media, and content marketing.",
    icon: "📈",
    serviceKey: "digitalMarketing",
  },
  {
    n: "06",
    t: "Creative Branding & Design",
    d: "Premium branding, graphic design, video content, and visual identity solutions for modern businesses.",
    icon: "🎨",
    serviceKey: "branding",
  },
];

const metrics = [
  { v: "250", l: "Projects completed", suffix: "+" },
  { v: "150", l: "Happy clients", suffix: "+" },
  { v: "98",  l: "Performance optimized", suffix: "+" },
  { v: "24",  l: "Client support", suffix: "/7" },
];

// ===== Component =====
export default function Home() {
  const [selectedKey, setSelectedKey] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const closeTimeoutRef = useRef(null);

  function openModal(key) {
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
    setSelectedKey(key);
    setModalOpen(true);
  }

  function closeModal() {
    setModalOpen(false);
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
    }
    closeTimeoutRef.current = setTimeout(() => {
      setSelectedKey(null);
      closeTimeoutRef.current = null;
    }, 300);
  }

  // ===== Scroll Reveal =====
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("revealed");
          }
        });
      },
      { threshold: 0.08 }
    );

    const revealElements = document.querySelectorAll(".reveal");
    revealElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  useSEO({
    title: "Powering Brands with AI-Driven Digital Excellence",
    description: "NamoAI Digital is a performance-driven agency delivering scalable, result-oriented services across content creation, digital marketing, branding, website & app development, and AI solutions.",
    keywords: "AI agency, digital marketing, website development, mobile apps, graphic design, content creation, branding, NamoAI Digital"
  });

  return (
    <div className="home page-transition-wrapper">

      {/* ===== HERO ===== */}
      <section className="hero">

        <Aurora
          colorStops={["#7cff67", "#B497CF", "#5227FF"]}
          blend={0.5}
          amplitude={1.0}
          speed={1}
        />

        <div className="grid-bg" />
        <div className="ambient hero-ambient" />

        <div className="container hero-inner">

          <span className="section-label reveal">
            <span
              className="dot"
              style={{
                display: "inline-block",
                width: 6,
                height: 6,
                borderRadius: "50%",
                background: "var(--accent-1)",
              }}
            />
            {" "}NAMOAI DIGITAL
          </span>

          <h1 className="hero-title reveal">
            Powering Brands with
            <br />
            AI-Driven Digital
            <br />
            <span className="text-gradient">Excellence</span>
          </h1>

          <p className="hero-sub reveal">
            NamoAI Digital helps brands grow through AI-powered
            websites, mobile apps, digital marketing,
            automation, and creative branding solutions
            built for modern businesses.
          </p>

          <div className="hero-stats reveal">
            <span><strong>90%</strong> Client Retention</span>
            <span className="divider">•</span>
            <span><strong>250+</strong> Projects Delivered</span>
            <span className="divider">•</span>
            <span><strong>5★</strong> Rated Agency</span>
          </div>

          <div className="hero-tags reveal">
            <span>Website Development</span>
            <span>App Development</span>
            <span>Digital Marketing</span>
            <span>Graphic Designing</span>
          </div>

          <div className="hero-cta reveal">
            <Link to="/contact" className="btn btn-primary glow-btn">
              Book Strategy Call →
            </Link>
            <Link to="/services" className="btn btn-ghost">
              Explore Services
            </Link>
          </div>

          <div className="trust reveal">
            <div className="avatars">
              <span>T</span>
              <span>A</span>
              <span>L</span>
              <span>N</span>
            </div>
            <div>
              <div className="trust-strong">Trusted by 150+ growing brands</div>
              <div className="muted" style={{ fontSize: 13 }}>
                Websites • Apps • Marketing • Branding
              </div>
            </div>
          </div>

        </div>

        {/* ===== LOGO STRIP ===== */}
        <div className="logo-strip reveal">
          <div className="container logo-marquee-title">
            <span className="mono-tiny">Trusted collaborations</span>
          </div>

          <div className="logo-marquee-wrap">
            <div className="logo-marquee-track">
              <div className="logo-marquee-content">
                {logos.map((l, idx) => (
                  <span key={`l-${idx}`} className="logo-item">{l}</span>
                ))}
              </div>
              <div className="logo-marquee-content" aria-hidden="true">
                {logos.map((l, idx) => (
                  <span key={`dup-${idx}`} className="logo-item">{l}</span>
                ))}
              </div>
            </div>
          </div>
        </div>

      </section>

      {/* ===== SERVICES ===== */}
      <section className="section">
        <div className="container">
          <div className="section-head reveal">
            <div>
              <span className="section-label">Services</span>
              <h2 className="section-title">
                AI-powered digital solutions.
                <span className="muted"> Built for business growth.</span>
              </h2>
            </div>
            <Link to="/services" className="link-arrow">All Services →</Link>
          </div>

          <div className="home-services">
            {services.map((s) => (
              <article
                key={s.n}
                className="service-card glass reveal"
                style={{ cursor: "pointer" }}
                onClick={() => openModal(s.serviceKey)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === "Enter" && openModal(s.serviceKey)}
                aria-label={`View ${s.t} pricing`}
              >
                <div className="service-overlay" />
                <div className="service-content">
                  <div className="service-top">
                    <div className="service-icon">{s.icon}</div>
                    <span className="mono-tiny">{s.n}</span>
                  </div>
                  <h3>{s.t}</h3>
                  <p>{s.d}</p>
                  <div className="card-footer">
                    <span className="view-plans-btn">View Plans →</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ===== WHY CHOOSE US ===== */}
      <section className="section divider-top">
        <div className="container">
          <div className="section-head-center reveal">
            <span className="section-label">Why Choose Us</span>
            <h2 className="section-title text-center">
              Smart technology. Creative execution.
            </h2>
          </div>

          <div className="why-grid">
            <div className="why-card glass reveal">
              <div className="why-icon">⚡</div>
              <h3>AI-Powered Solutions</h3>
              <p className="muted">
                Leveraging AI technology to automate workflows,
                improve efficiency, and accelerate growth.
              </p>
            </div>

            <div className="why-card glass reveal">
              <div className="why-icon">🎨</div>
              <h3>Creative Branding</h3>
              <p className="muted">
                Premium branding, graphics, and UI/UX designed
                to create a strong digital identity.
              </p>
            </div>

            <div className="why-card glass reveal">
              <div className="why-icon">📈</div>
              <h3>Growth Focused</h3>
              <p className="muted">
                Every strategy is optimized for engagement,
                conversions, and long-term business growth.
              </p>
            </div>

            <div className="why-card glass reveal">
              <div className="why-icon">⚙️</div>
              <h3>Modern Technology</h3>
              <p className="muted">
                Built using modern stacks and scalable systems
                for high performance and reliability.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ===== METRICS ===== */}
      <section className="section-sm divider-top">
        <div className="container metrics-grid">
          {metrics.map((m) => (
            <div key={m.l} className="metric reveal">
              <div className="metric-v">
                <AnimatedCounter value={m.v} suffix={m.suffix} />
              </div>
              <div className="metric-l">{m.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ===== TESTIMONIALS ===== */}
      <section className="section divider-top">
        <div className="container">
          <div className="section-head reveal">
            <div>
              <span className="section-label">Client Success</span>
              <h2 className="section-title">Don't just take our word for it.</h2>
            </div>
          </div>
          <TestimonialsCarsoule />
        </div>
      </section>

      {/* ===== CTA ===== */}
      <section className="section">
        <div className="container">
          <div className="cta-card reveal">
            <div className="ambient" />
            <div className="cta-inner">
              <span className="section-label">Start Your Digital Growth</span>

              <h2 className="section-title">
                Ready to grow your business
                <br />
                with
                <span className="text-gradient"> AI-powered solutions?</span>
              </h2>

              <p className="muted" style={{ maxWidth: "560px", margin: "16px auto 0" }}>
                Contact NamoAI Digital for websites, applications, branding,
                digital marketing, automation, and creative solutions designed
                for modern businesses.
              </p>

              <p className="muted" style={{ marginTop: 10 }}>
                www.namoaidigital.in
              </p>

              <p className="muted">digitalnamoai@gmail.com</p>

              <div className="hero-cta" style={{ marginTop: 32 }}>
              <Link to="/contact" className="btn btn-primary glow-btn">
  Contact Us →
</Link>


 <a href="https://wa.me/919579057085"
  target="_blank"
  rel="noreferrer"
  className="btn btn-ghost">
  Chat on WhatsApp
</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== MODAL ===== */}
      <ServicePricingModal
        serviceKey={selectedKey}
        isOpen={modalOpen}
        onClose={closeModal}
      />

    </div>
  );
}
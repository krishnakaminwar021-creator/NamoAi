import React from "react";
import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="page-header" style={{ minHeight: "70vh", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
      <div className="container" style={{ textAlign: "center" }}>
        <h1 style={{ fontSize: "clamp(60px, 15vw, 120px)", marginBottom: "16px", letterSpacing: "-0.05em" }} className="text-gradient">404</h1>
        <h2 style={{ fontSize: "clamp(24px, 5vw, 32px)", marginBottom: "24px" }}>Page Not Found</h2>
        <p className="muted" style={{ maxWidth: "500px", margin: "0 auto 40px" }}>
          The page you are looking for doesn't exist or has been moved. Let's get you back on track.
        </p>
        <Link to="/" className="btn btn-primary" style={{ display: "inline-flex" }}>
          Return Home
        </Link>
      </div>
    </div>
  );
}

import { useEffect, useState, useRef } from "react";
import { createPortal } from "react-dom";
import "./OpenRoles.css";
const SHEET_URL =
  "https://script.google.com/macros/s/AKfycbzbMr0X6ZBZLJ5BNw8w0urkst26kEFSvZbps_wZzNfByDBo9KvZ-xw_OVdE21PRxlKa5Q/exec";

const benefits = [
  { title: "Real-world projects", desc: "Work on high-impact projects that directly contribute to client success and growth." },
  { title: "Startup learning", desc: "Gain massive exposure to startup operations, strategy development, and decision-making." },
  { title: "Flexible culture", desc: "Maintain a healthy work-life balance with a culture that values output over clocking hours." },
  { title: "Leadership opportunities", desc: "Take ownership of initiatives early and guide projects from concept to final delivery." },
  { title: "AI exposure", desc: "Integrate cutting-edge AI technologies and automated workflows into everyday systems." },
  { title: "Collaboration", desc: "Work closely with multidisciplinary experts across design, code, and growth marketing." },
  { title: "Performance growth", desc: "Benefit from regular reviews, skill expansions, and performance-linked opportunities." },
  { title: "Mentorship & Guidance", desc: "Get continuous support from experienced mentors to accelerate your personal and professional growth." },
];

const roles = [
  {
    title: "Business Development Executive",
    location: "(On-site / Hybrid)",
    responsibilities: [
      "Identify potential clients and generate quality leads for web, app, and AI services.",
      "Conduct outreach campaigns via Email, LinkedIn, and cold channels.",
      "Pitch NAMOAI Digital's services and prepare business proposals.",
      "Negotiate and close deals to achieve monthly business growth targets.",
    ],
    requirements: [
      "Strong communication, negotiation, and interpersonal skills.",
      "Highly tech-savvy with a solid understanding of digital and web services.",
      "Prior experience in B2B tech sales or business development is preferred.",
      "Self-driven attitude and ability to thrive in a fast-paced environment.",
    ],
  },
  {
    title: "Digital Marketing Executive",
    location: "(On-site / Hybrid)",
    responsibilities: [
      "Set up, manage, and optimize Google Ads and Meta Ads campaigns.",
      "Analyze keyword trends, search terms, and execute high-ROI SEO strategies.",
      "Perform A/B testing on ad copies, landers, and creative banners.",
      "Track and report key performance metrics, conversions, and acquisition costs.",
    ],
    requirements: [
      "In-depth knowledge of Google Search Console, Analytics, and Meta Ads Manager.",
      "Analytical mindset with the ability to interpret data and adjust ad spends.",
      "Strong copywriting skills for ads, headlines, and call-to-actions.",
      "1+ years of experience in performance marketing is a plus.",
    ],
  },
  {
    title: "Social Media Manager",
    location: "(On-site / Hybrid)",
    responsibilities: [
      "Manage social media accounts for NAMOAI Digital and client portfolios.",
      "Design content calendars and write engaging copies for LinkedIn, Instagram, and X.",
      "Build community engagement by actively responding to comments and inquiries.",
      "Analyze engagement metrics and tweak content formats to boost viral reach.",
    ],
    requirements: [
      "Creative eye for layout, typography, and visual brand consistency.",
      "Familiarity with graphic tools like Canva and basic video editing tools.",
      "Deep understanding of current social media algorithms, trends, and hooks.",
      "Excellent communication and storytelling capabilities.",
    ],
  },
  {
    title: "Web Developer",
    location: "(On-site / Hybrid)",
    responsibilities: [
      "Build responsive, high-performance web applications using React & modern stacks.",
      "Collaborate with UI/UX designers to translate Figma mockups into pixel-perfect code.",
      "Integrate backend REST APIs, webhooks, and third-party tools.",
      "Perform cross-browser testing and optimize page load speeds.",
    ],
    requirements: [
      "Proficient in HTML5, CSS3 (Vanilla & modern utilities), JavaScript, and React.",
      "Familiarity with version control (Git) and hosting services like Vercel/Netlify.",
      "Strong problem-solving skills and clean code architecture principles.",
      "Knowledge of Next.js, Vite, or Tailwind CSS is highly preferred.",
    ],
  },
  {
    title: "UI/UX Designer",
    location: "(On-site / Hybrid)",
    responsibilities: [
      "Create high-fidelity wireframes, user flows, and prototypes in Figma.",
      "Establish and maintain scalable design systems, typography guidelines, and icons.",
      "Analyze user feedback to simplify complex interactions and layouts.",
      "Collaborate with developers to ensure the integrity of the design implementation.",
    ],
    requirements: [
      "Exceptional Figma skills and a strong portfolio demonstrating modern UI/UX principles.",
      "Solid understanding of user psychology, hierarchy, accessibility, and visual aesthetics.",
      "Detail-oriented with a passion for micro-animations and micro-interactions.",
      "Strong presentation skills to communicate design concepts clearly.",
    ],
  },
  {
    title: "Graphic Designer & Video Editor",
    location: "(On-site / Hybrid)",
    responsibilities: [
      "Design premium marketing materials, social media creatives, and slide decks.",
      "Edit high-converting reels, promotional video assets, and case studies.",
      "Integrate audio transitions, sound effects, subtitles, and dynamic visual graphics.",
      "Ensure all visual outputs align with brand tone and guidelines.",
    ],
    requirements: [
      "Proficient in Adobe Premiere Pro, After Effects, Photoshop, and Illustrator.",
      "Solid understanding of pacing, storytelling, sound design, and color grading.",
      "Ability to handle multiple graphic styles, formats, and design formats.",
      "Fast turnaround time with excellent attention to visual quality.",
    ],
  },
  {
    title: "AI & Automation Intern",
    location: "(On-site / Hybrid)",
    responsibilities: [
      "Map out business workflows and build integrations using Make.com, Zapier, and APIs.",
      "Develop custom AI assistants, chatbots, and email sequences using LLMs.",
      "Write scripts to parse, format, and push data between SaaS systems.",
      "Document automated workflows and train internal teams on system usages.",
    ],
    requirements: [
      "Basic understanding of API requests, JSON payloads, and scripting (JS or Python).",
      "Hands-on experience or interest in Make.com, Zapier, and OpenAI/Anthropic APIs.",
      "Excellent logical reasoning and process-mapping abilities.",
      "Highly proactive and eager to learn the latest AI capabilities.",
    ],
  },
  {
    title: "HR & Talent Acquisition Intern",
    location: "(On-site / Hybrid)",
    responsibilities: [
      "Source and screen potential candidates for open engineering, creative, and sales roles.",
      "Coordinate interview schedules and communicate onboarding steps to selected candidates.",
      "Develop engaging workplace culture policies and employee engagement activities.",
      "Maintain HR documentation, candidate trackers, and internally public updates.",
    ],
    requirements: [
      "Outstanding communication and organizational management skills.",
      "Pursuing or holding a degree in HR, Business Management, or a related stream.",
      "Empathetic mindset with the ability to build rapport with candidates.",
      "Knowledge of LinkedIn sourcing and hiring portals is a plus.",
    ],
  },
];

const internships = [
  "Digital Marketing",
  "Web Development",
  "App Development",
  "Graphic Design",
  "Video Editing",
  "Business Development",
  "Human Resources",
  "AI & Automation",
];

const timelineSteps = [
  { num: "1", title: "Submit Application", desc: "Send your updated resume and portfolio link to our team via email." },
  { num: "2", title: "Screening", desc: "Our HR team reviews your application against the role requirements." },
  { num: "3", title: "Assessment", desc: "Complete a short take-home technical or creative assignment to demonstrate your skills." },
  { num: "4", title: "Interview", desc: "Discuss your work, expectations, and cultural alignment with department heads." },
  { num: "5", title: "Onboarding", desc: "Get welcomed into the NAMOAI team and begin building modern digital solutions." },
];

const EMPTY_FORM = { name: "", email: "", phone: "", experience: "", portfolio: "", linkedin: "", message: "" };

const validateField = (name, value) => {
  if (name === "name") {
    return value.trim() ? "" : "Full name is required.";
  }
  if (name === "email") {
    if (!value.trim()) return "Email is required.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return "Enter a valid email address.";
    return "";
  }
  if (name === "phone") {
    return value.trim() ? "" : "Phone number is required.";
  }
  if (name === "experience") {
    return value ? "" : "Please select your experience level.";
  }
  if (name === "portfolio") {
    if (!value.trim()) return "Portfolio URL is required.";
    try { new URL(value.startsWith("http") ? value : `https://${value}`); return ""; } catch { return "Please enter a valid portfolio URL."; }
  }
  if (name === "linkedin") {
    if (!value.trim()) return "LinkedIn profile URL is required.";
    const linkedinRegex = /^(https?:\/\/)?(www\.)?linkedin\.com\/in\/.+/i;
    if (!linkedinRegex.test(value)) return "Please enter a valid LinkedIn profile URL (e.g. linkedin.com/in/username).";
    return "";
  }
  return "";
};

/* ── Modal — rendered via createPortal directly into <body> so
   overflow-x:hidden on .open-roles-page cannot trap it ── */
function ApplicationModal({ selectedRole, onClose }) {
  const [formData, setFormData] = useState(EMPTY_FORM);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [showToast, setShowToast] = useState(false);
  const [errors, setErrors]     = useState({});
  const overlayRef = useRef(null);
  const mouseDownTargetRef = useRef(null);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, []);

  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => setShowToast(false), 4000);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  const handleOverlayClick = (e) => {
    if (e.target === overlayRef.current && mouseDownTargetRef.current === overlayRef.current) {
      onClose();
    }
  };

  const validate = () => {
    const errs = {};
    const fields = ["name", "email", "phone", "experience", "portfolio", "linkedin"];
    fields.forEach((field) => {
      const err = validateField(field, formData[field] || "");
      if (err) errs[field] = err;
    });
    return errs;
  };


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((p) => {
      const next = { ...p, [name]: value };
      const err = validateField(name, value);
      if (!err) {
        setErrors((prev) => ({ ...prev, [name]: undefined }));
      } else if (errors[name]) {
        setErrors((prev) => ({ ...prev, [name]: err }));
      }
      return next;
    });
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    const err = validateField(name, value);
    setErrors((prev) => ({ ...prev, [name]: err || undefined }));
  };

  const handleSubmit = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    console.log("HANDLE SUBMIT CALLED");
    if (submitting) return;

    const errs = validate();
    console.log("Validation errors:", errs);
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }

    setSubmitting(true);
    setSubmitError(null);

    try {
      const payload = {
        role: selectedRole,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        experience: formData.experience,
        portfolio: formData.portfolio,
        linkedin: formData.linkedin,
        message: formData.message,
        timestamp: new Date().toISOString(),
      };

      console.log("Submitting payload:", payload);

      const response = await fetch(SHEET_URL, {
        method: "POST",
        body: JSON.stringify(payload),
      });

      const text = await response.text();
      console.log("Response status:", response.status);
      console.log("Response body:", text);

      if (!response.ok) {
        throw new Error("Server returned an error. Please try again.");
      }

      setSubmitted(true);
      setShowToast(true);
    } catch (err) {
      console.error("Submission failed:", err);
      setSubmitError(err.message || "Network error. Please check your internet connection and try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleClose = () => {
    setFormData(EMPTY_FORM);
    setErrors({});
    setSubmitted(false);
    setSubmitError(null);
    setShowToast(false);
    onClose();
  };


  const modal = (
    <>
      <style>{`
        .app-overlay {
          position: fixed;
          inset: 0;
          z-index: 99999;
          background: rgba(0,0,0,0.75);
          backdrop-filter: blur(6px);
          -webkit-backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 1rem;
          animation: app-fadeIn 0.2s ease;
          pointer-events: auto;
        }
        @keyframes app-fadeIn { from{opacity:0} to{opacity:1} }

        .app-card {
          width: 100%;
          max-width: 680px;
          max-height: 92vh;
          overflow-y: auto;
          border-radius: 20px;
          padding: 2rem 2.25rem;
          background: var(--glass-bg, #13131f);
          border: 1px solid var(--border, rgba(255,255,255,0.1));
          animation: app-scaleIn 0.25s cubic-bezier(0.34,1.38,0.64,1);
          scrollbar-width: thin;
          pointer-events: auto;
        }
        @keyframes app-scaleIn {
          from{opacity:0;transform:scale(0.93) translateY(14px)}
          to  {opacity:1;transform:scale(1)    translateY(0)}
        }

        .app-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 1rem;
          border-bottom: 1px solid var(--border, rgba(255,255,255,0.08));
          padding-bottom: 1.25rem;
          margin-bottom: 1.75rem;
        }
        .app-eyebrow {
          font-family: "JetBrains Mono", monospace;
          font-size: 11px;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: var(--accent-1, #5b8cff);
          margin: 0 0 5px;
        }
        .app-role-title {
          font-size: 1.2rem;
          font-weight: 600;
          margin: 0;
          color: var(--text, #fff);
          line-height: 1.3;
        }
        .app-close {
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.1);
          color: var(--text, #fff);
          width: 34px; height: 34px;
          border-radius: 10px;
          font-size: 14px;
          cursor: pointer;
          flex-shrink: 0;
          display: flex; align-items: center; justify-content: center;
          transition: background 0.15s;
        }
        .app-close:hover { background: rgba(255,255,255,0.12); }

        .app-form { display: flex; flex-direction: column; gap: 1rem; }

        .app-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }
        @media (max-width: 540px) {
          .app-row { grid-template-columns: 1fr; }
          .app-card { padding: 1.4rem 1.2rem; }
        }

        .app-group { display: flex; flex-direction: column; gap: 6px; }
        .app-label {
          font-family: "Space Grotesk", sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: var(--text-muted, rgba(255,255,255,0.5));
        }
        .app-required { color: #e05c5c; }

        .app-group input,
        .app-group select,
        .app-group textarea {
          background: rgba(255,255,255,0.05);
          border: 1px solid var(--border, rgba(255,255,255,0.1));
          border-radius: 10px;
          padding: 0.65rem 0.9rem;
          color: var(--text, #fff);
          font-size: 14px;
          font-family: inherit;
          outline: none;
          transition: border-color 0.15s, background 0.15s;
          width: 100%;
          box-sizing: border-box;
          resize: vertical;
        }
        .app-group input::placeholder,
        .app-group textarea::placeholder { color: rgba(255,255,255,0.25); }
        .app-group select option { background: #13131f; color: #fff; }
        .app-group input:focus,
        .app-group select:focus,
        .app-group textarea:focus {
          border-color: var(--accent-1, #5b8cff);
          background: rgba(255,255,255,0.08);
        }
        .app-group.has-error input,
        .app-group.has-error select,
        .app-group.has-error textarea { border-color: #e05c5c; }
        .app-field-err { font-size: 12px; color: #e05c5c; margin: 0; }

        .app-footer {
          display: flex;
          justify-content: flex-end;
          gap: 0.75rem;
          padding-top: 1.25rem;
          border-top: 1px solid var(--border, rgba(255,255,255,0.08));
          margin-top: 0.25rem;
        }
        .app-btn-ghost {
          background: transparent;
          border: 1px solid rgba(255,255,255,0.15);
          color: var(--text, #fff);
          padding: 0.6rem 1.25rem;
          border-radius: 10px;
          font-size: 14px;
          font-family: inherit;
          cursor: pointer;
          transition: background 0.15s;
        }
        .app-btn-ghost:hover { background: rgba(255,255,255,0.07); }

        .app-success {
          text-align: center;
          padding: 2rem 1rem 1rem;
        }
        .app-success-icon {
          width: 56px; height: 56px;
          border-radius: 50%;
          background: linear-gradient(135deg, #5b8cff, #a855f7);
          display: flex; align-items: center; justify-content: center;
          font-size: 1.4rem;
          color: #fff;
          margin: 0 auto 1.25rem;
        }
        .app-success h3 {
          font-size: 1.25rem;
          font-weight: 600;
          margin: 0 0 0.6rem;
          color: var(--text, #fff);
        }
        .app-success p {
          font-size: 14px;
          color: var(--text-muted, rgba(255,255,255,0.55));
          margin: 0 0 1.5rem;
          line-height: 1.6;
        }
        .app-success strong { color: var(--accent-1, #5b8cff); }

        .app-error-banner {
          background: rgba(239, 68, 68, 0.1);
          border: 1px solid rgba(239, 68, 68, 0.35);
          border-radius: 12px;
          padding: 10px 14px;
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 0.5rem;
        }
        .app-error-icon {
          font-size: 16px;
          flex-shrink: 0;
        }
        .app-error-content {
          display: flex;
          justify-content: space-between;
          align-items: center;
          width: 100%;
          gap: 12px;
        }
        .app-retry-btn {
          background: rgba(239, 68, 68, 0.2);
          border: 1px solid rgba(239, 68, 68, 0.4);
          color: #fca5a5;
          padding: 4px 10px;
          border-radius: 6px;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          transition: background 0.15s;
        }
        .app-retry-btn:hover {
          background: rgba(239, 68, 68, 0.3);
        }

        .toast-success-banner {
          position: fixed;
          bottom: 24px;
          right: 24px;
          z-index: 100000;
          background: rgba(16, 16, 24, 0.9);
          border: 1px solid rgba(34, 197, 94, 0.4);
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5), 0 0 20px rgba(34, 197, 94, 0.1);
          border-radius: 16px;
          padding: 12px 18px;
          display: flex;
          align-items: center;
          gap: 12px;
          backdrop-filter: blur(16px);
          -webkit-backdrop-filter: blur(16px);
          animation: toast-slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
        @keyframes toast-slideIn {
          from { opacity: 0; transform: translateY(20px) scale(0.95); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        .toast-success-icon {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #22c55e;
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: bold;
          flex-shrink: 0;
        }
        .toast-success-content {
          display: flex;
          flex-direction: column;
          text-align: left;
        }
        .toast-success-title {
          font-size: 13px;
          font-weight: 600;
          color: #fff;
        }
        .toast-success-desc {
          font-size: 11px;
          color: rgba(255, 255, 255, 0.6);
        }
        .toast-success-close {
          background: transparent;
          border: none;
          color: rgba(255, 255, 255, 0.4);
          cursor: pointer;
          font-size: 12px;
          padding: 4px;
          transition: color 0.15s;
        }
        .toast-success-close:hover {
          color: #fff;
        }
      `}</style>

      <div
        className="app-overlay"
        ref={overlayRef}
        onMouseDown={(e) => { mouseDownTargetRef.current = e.target; }}
        onTouchStart={(e) => { mouseDownTargetRef.current = e.target; }}
        onClick={handleOverlayClick}
        role="dialog"
        aria-modal="true"
        aria-labelledby="app-modal-title"
      >
        <div className="app-card">
          <div className="app-header">
            <div>
              <p className="app-eyebrow">Applying for</p>
              <h2 id="app-modal-title" className="app-role-title">{selectedRole}</h2>
            </div>
            <button className="app-close" onClick={handleClose} aria-label="Close" disabled={submitting}>✕</button>
          </div>

          {submitted ? (
            <div className="app-success">
              <div className="app-success-icon">✓</div>
              <h3>Application Received!</h3>
              <p>
                Thanks for applying for <strong>{selectedRole}</strong>. Our team will review
                your profile and reach out within 3–5 business days.
              </p>
              <button className="btn btn-primary" onClick={handleClose}>Back to Roles</button>
            </div>
          ) : (
            <form
              className="app-form"
              onSubmit={(e) => e.preventDefault()}
              noValidate
            >
              <div className="app-row">
                <div className={`app-group${errors.name ? " has-error" : ""}`}>
                  <label className="app-label">Full Name <span className="app-required">*</span></label>
                  <input type="text" name="name" placeholder="Jane Doe"
                    value={formData.name} onChange={handleChange} onBlur={handleBlur} autoComplete="name" autoFocus />
                  {errors.name && <p className="app-field-err">{errors.name}</p>}
                </div>
                <div className={`app-group${errors.email ? " has-error" : ""}`}>
                  <label className="app-label">Email Address <span className="app-required">*</span></label>
                  <input type="email" name="email" placeholder="jane@example.com"
                    value={formData.email} onChange={handleChange} onBlur={handleBlur} autoComplete="email" />
                  {errors.email && <p className="app-field-err">{errors.email}</p>}
                </div>
              </div>

              <div className="app-row">
                <div className={`app-group${errors.phone ? " has-error" : ""}`}>
                  <label className="app-label">Phone Number <span className="app-required">*</span></label>
                  <input type="tel" name="phone" placeholder="+91 98765 43210"
                    value={formData.phone} onChange={handleChange} onBlur={handleBlur} autoComplete="tel" />
                  {errors.phone && <p className="app-field-err">{errors.phone}</p>}
                </div>
                <div className={`app-group${errors.experience ? " has-error" : ""}`}>
                  <label className="app-label">Experience Level <span className="app-required">*</span></label>
                  <select name="experience" value={formData.experience} onChange={handleChange} onBlur={handleBlur}>
                    <option value="">Select level…</option>
                    <option value="fresher">Fresher / No experience</option>
                    <option value="0-1">Less than 1 year</option>
                    <option value="1-2">1–2 years</option>
                    <option value="2-4">2–4 years</option>
                    <option value="4+">4+ years</option>
                  </select>
                  {errors.experience && <p className="app-field-err">{errors.experience}</p>}
                </div>
              </div>

              <div className="app-row">
                <div className={`app-group${errors.portfolio ? " has-error" : ""}`}>
                  <label className="app-label">Portfolio URL <span className="app-required">*</span></label>
                  <input type="url" name="portfolio" placeholder="https://yourportfolio.com"
                    value={formData.portfolio} onChange={handleChange} onBlur={handleBlur} />
                  {errors.portfolio && <p className="app-field-err">{errors.portfolio}</p>}
                </div>
                <div className={`app-group${errors.linkedin ? " has-error" : ""}`}>
                  <label className="app-label">LinkedIn Profile URL <span className="app-required">*</span></label>
                  <input type="url" name="linkedin" placeholder="https://linkedin.com/in/username"
                    value={formData.linkedin} onChange={handleChange} onBlur={handleBlur} />
                  {errors.linkedin && <p className="app-field-err">{errors.linkedin}</p>}
                </div>
              </div>

              <div className="app-group">
                <label className="app-label">Cover Message</label>
                <textarea name="message" rows={4}
                  placeholder="Tell us why you're a great fit for this role…"
                  value={formData.message} onChange={handleChange} />
              </div>

              {submitError && (
                <div className="app-error-banner">
                  <span className="app-error-icon">⚠️</span>
                  <div className="app-error-content">
                    <p className="app-field-err" style={{ fontSize: "13px" }}>{submitError}</p>
                    <button type="button" className="app-retry-btn" onClick={handleSubmit}>Retry</button>
                  </div>
                </div>
              )}

              <div className="app-footer">
                <button type="button" className="app-btn-ghost" onClick={handleClose} disabled={submitting}>Cancel</button>
                <button
                  type="button"
                  className="btn btn-primary"
                  style={{ opacity: submitting ? 0.7 : 1, cursor: submitting ? "not-allowed" : "pointer" }}
                  onClick={(e) => {
                    console.log("SUBMIT BUTTON CLICKED");
                    handleSubmit(e);
                  }}
                >
                  {submitting ? "Submitting..." : "Submit Application →"}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {showToast && (
        <div className="toast-success-banner" role="alert">
          <div className="toast-success-icon">✓</div>
          <div className="toast-success-content">
            <span className="toast-success-title">Application Submitted!</span>
            <span className="toast-success-desc">We will review your profile shortly.</span>
          </div>
          <button className="toast-success-close" onClick={() => setShowToast(false)}>✕</button>
        </div>
      )}
    </>
  );

  return createPortal(modal, document.body);
}

/* ── Main Page ── */
export default function OpenRoles() {
  const [selectedRole, setSelectedRole] = useState(null);
  const [isOpen, setIsOpen]             = useState(false);

  const openModal  = (title) => { setSelectedRole(title); setIsOpen(true); };
  const closeModal = ()       => { setIsOpen(false); setSelectedRole(null); };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("revealed"); }),
      { threshold: 0.08, rootMargin: "0px 0px -50px 0px" }
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <div className="open-roles-page page-transition-wrapper">
      {isOpen && selectedRole && (
        <ApplicationModal selectedRole={selectedRole} onClose={closeModal} />
      )}

      {/* Hero */}
      <section className="page-header">
        <div className="grid-bg" />
        <div className="container">
          <span className="section-label">Careers</span>
          <h1>Careers – <span className="text-gradient">Open Roles</span> at NAMOAI Digital</h1>
          <p className="hero-desc">
            Join the Team Building the Future of Digital Innovation. At NAMOAI Digital, we
            prioritize structure, execution, and technological progress. We are looking for
            self-starters ready to turn creative concepts into high-performance web systems
            and AI automations.
          </p>
        </div>
      </section>

      {/* Benefits */}
      <section className="section divider-top">
        <div className="container">
          <div className="section-head-center reveal">
            <span className="section-label">Benefits</span>
            <h2 className="section-title text-center">Why Work With Us?</h2>
            <p className="section-subtext muted">
              We offer a growth-driven ecosystem built to refine your skills and elevate your career.
            </p>
          </div>
          <div className="benefits-grid reveal-stagger">
            {benefits.map((b, idx) => (
              <div key={idx} className="benefit-card glass reveal">
                <div className="benefit-icon">✓</div>
                <h3>{b.title}</h3>
                <p className="muted">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Open Roles */}
      <section className="section divider-top">
        <div className="container">
          <div className="section-head reveal">
            <div>
              <span className="section-label">Join Our Team</span>
              <h2 className="section-title">Current Open Roles</h2>
            </div>
            <span className="mono-tiny">8 POSITIONS ACTIVE</span>
          </div>
          <div className="roles-list reveal-stagger">
            {roles.map((role, idx) => (
              <div key={idx} className="role-card glass reveal">
                <div className="role-header">
                  <h3>{role.title}</h3>
                  <span className="role-loc">{role.location}</span>
                </div>
                <div className="role-content">
                  <div className="role-section">
                    <h4>Key Responsibilities:</h4>
                    <ul>{role.responsibilities.map((r, ri) => <li key={ri}>{r}</li>)}</ul>
                  </div>
                  <div className="role-section">
                    <h4>Requirements:</h4>
                    <ul>{role.requirements.map((req, rqi) => <li key={rqi}>{req}</li>)}</ul>
                  </div>
                </div>
                <div className="role-footer">
                  <button className="btn btn-primary" onClick={() => openModal(role.title)}>
                    Apply Now →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Internships */}
      <section className="section divider-top">
        <div className="container">
          <div className="section-head-center reveal">
            <span className="section-label">Internships</span>
            <h2 className="section-title text-center">Internship Opportunities</h2>
            <p className="section-subtext muted">
              Start your career with hands-on mentoring. We are offering structured internships in:
            </p>
          </div>
          <div className="internship-grid reveal-stagger">
            {internships.map((intern, idx) => (
              <div key={idx} className="intern-card glass reveal">
                <div className="intern-dot" />
                <span className="intern-name">{intern}</span>
                <button className="intern-link" onClick={() => openModal(intern + " Internship")}>
                  Apply →
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="section divider-top">
        <div className="container">
          <div className="section-head-center reveal">
            <span className="section-label">Our Process</span>
            <h2 className="section-title text-center">Application Process</h2>
            <p className="section-subtext muted">How we find talent and welcome them on board.</p>
          </div>
          <div className="timeline-wrap reveal">
            {timelineSteps.map((step, idx) => (
              <div key={idx} className="timeline-step">
                <div className="timeline-num-box">
                  <span className="timeline-num">{step.num}</span>
                  {idx < timelineSteps.length - 1 && <div className="timeline-line" />}
                </div>
                <div className="timeline-content glass">
                  <h3>{step.title}</h3>
                  <p className="muted">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section divider-top">
        <div className="container">
          <div className="cta-card reveal">
            <div className="ambient" />
            <div className="cta-inner">
              <span className="section-label">Join NAMOAI</span>
              <h2 className="section-title">Ready to Build Something Great?</h2>
              <div className="cta-info-grid">
                <div className="cta-info-item">
                  <span className="mono-tiny">Email Us</span>
                <a
  href="https://mail.google.com/mail/?view=cm&fs=1&to=namoaidigital09@gmail.com"
  target="_blank"
  rel="noopener noreferrer"
  className="cta-link"
>
  digitalnamoai@gmail.com
</a>
                </div>
                <div className="cta-info-item">
                  <span className="mono-tiny">Location</span>
                  <span className="cta-text">Nanded, Maharashtra, India</span>
                </div>
              </div>
              <p className="cta-tagline">Grow with us. Innovate with us. Lead with us.</p>
              <div className="hero-cta" style={{ marginTop: 24 }}>
                <button className="btn btn-primary" onClick={() => openModal("General Application")}>
                  Apply Now →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

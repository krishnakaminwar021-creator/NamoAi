import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Portfolio.css';

const portfolios = [
  {
    category: 'Developer Portfolio',
    description:
      'High-performance websites, web applications, and digital platforms built with modern technology stacks.',
    link: 'https://linkmaker.in/5cQufw',
    tags: ['React', 'Next.js', 'Full Stack', 'Mobile Apps'],
    stats: { projects: '40+', clients: '18+' },
  },

  {
    category: 'Marketing Portfolio',
    description:
      'Performance marketing campaigns, SEO strategies, social media growth, paid advertising, and lead generation solutions that drive measurable business results.',
    link: 'https://linkmaker.in/n5EIXf',
    tags: ['SEO', 'Meta Ads', 'Google Ads', 'Lead Generation'],
    stats: { projects: '30+', clients: '12+' },
  },

  {
    category: 'Video Editing Portfolio',
    description:
      'Cinematic edits, reels, promotional videos, and motion graphics that capture attention and drive engagement.',
    link: 'https://namoaivideoeditorportfollio.my.canva.site/',
    tags: ['Reels', 'Promo Videos', 'Motion Graphics', 'YouTube'],
    stats: { projects: '35+', clients: '15+' },
  },

  {
    category: 'Graphic Design Portfolio',
    description:
      'Brand identities, social media creatives, marketing collateral, and visual design systems crafted with precision.',
    link: 'https://linkmaker.in/MBtkg3',
    tags: ['Brand Identity', 'Social Media', 'Print Design', 'Visual Systems'],
    stats: { projects: '45+', clients: '20+' },
  },
];

export default function Portfolio() {

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('revealed');
          }
        });
      },
      { threshold: 0.08, rootMargin: '0px 0px -50px 0px' }
    );

    document
      .querySelectorAll('.reveal')
      .forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  // ICON MAPPING
  const renderIcon = (category) => {
    switch (category) {

      case 'Developer Portfolio':
        return (
          <>
            <polyline points="16 18 22 12 16 6" />
            <polyline points="8 6 2 12 8 18" />
          </>
        );

      case 'Marketing Portfolio':
        return (
          <>
            <path d="M3 11v10" />
            <path d="M7 7v14" />
            <path d="M11 13v8" />
            <path d="M15 4v17" />
            <path d="M19 8v13" />
          </>
        );

      case 'Video Editing Portfolio':
        return (
          <>
            <polygon points="23 7 16 12 23 17 23 7" />
            <rect x="1" y="5" width="15" height="14" rx="2" />
          </>
        );

      case 'Graphic Design Portfolio':
        return (
          <>
            <rect x="3" y="3" width="18" height="18" rx="2" />
            <circle cx="8.5" cy="8.5" r="1.5" />
            <path d="m21 15-5-5L5 21" />
          </>
        );

      default:
        return null;
    }
  };

  return (
    <div>

      <section className="page-header">
        <div className="grid-bg" />

        <div className="container">
          <span className="section-label">Portfolio</span>

          <h1>
            Our <span className="text-gradient">Creative Work.</span>
          </h1>

          <p>
            Explore our portfolio across graphic design,
            video production, and development.
            Real work, real results.
          </p>
        </div>
      </section>

      <section className="section">

        <div className="container portfolio-grid reveal-stagger">

          {portfolios.map((p, i) => (

            <a
              key={p.category}
              href={p.link}
              target="_blank"
              rel="noopener noreferrer"
              className="portfolio-card glass reveal delay-1"
              style={{ '--delay': `${i * 0.1}s` }}
              onClick={() =>
                console.log(`Opened portfolio: ${p.category}`)
              }
            >

              <div className="portfolio-card-header">

                <span className="portfolio-num mono-tiny">
                  {String(i + 1).padStart(2, '0')}
                </span>

                <div className="portfolio-category-icon">

                  <svg
                    viewBox="0 0 24 24"
                    width="24"
                    height="24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.5"
                  >
                    {renderIcon(p.category)}
                  </svg>

                </div>
              </div>

              <h2>{p.category}</h2>

              <p className="portfolio-desc">
                {p.description}
              </p>

              <div className="portfolio-tags">

                {p.tags.map((tag) => (
                  <span
                    key={tag}
                    className="portfolio-tag"
                  >
                    {tag}
                  </span>
                ))}

              </div>

              <div className="portfolio-stats">

                <div>
                  <span className="portfolio-stat-v">
                    {p.stats.projects}
                  </span>

                  <span className="portfolio-stat-l">
                    Projects
                  </span>
                </div>

                <div>
                  <span className="portfolio-stat-v">
                    {p.stats.clients}
                  </span>

                  <span className="portfolio-stat-l">
                    Clients
                  </span>
                </div>

              </div>

              <span className="portfolio-btn">
                Open Drive Portfolio{' '}
                <span aria-hidden="true">↗</span>
              </span>

            </a>
          ))}

        </div>
      </section>

      <section
        className="section divider-top"
        style={{ textAlign: 'center' }}
      >

        <div className="container reveal">

          <h2
            className="section-title"
            style={{ margin: '0 auto' }}
          >
            Want to see more?
          </h2>

          <p
            className="muted"
            style={{
              maxWidth: 520,
              margin: '16px auto 32px',
            }}
          >
            Let’s discuss how we can create something
            exceptional for your brand.
          </p>

          <Link
            to="/contact"
            className="btn btn-primary"
          >
            Start a Project →
          </Link>

        </div>
      </section>

    </div>
  );
}
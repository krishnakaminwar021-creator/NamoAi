import React from "react";
import "./Legal.css";

export default function PrivacyPolicy() {
  return (
    <div className="legal-page">
      {/* Hero */}
      <div className="legal-hero">
        <h1>Privacy <span className="text-gradient">Policy</span></h1>
        <p className="legal-subtitle">
          Your privacy is important to us. This policy outlines how NAMOAI Digital collects, uses, and protects your personal information.
        </p>
        <span className="legal-effective-date">Effective: June 1, 2025</span>
      </div>

      {/* Content */}
      <div className="legal-content-wrapper">

        {/* 1 */}
        <div className="legal-section">
          <span className="legal-section-number">Section 01</span>
          <h2>Introduction</h2>
          <p>
            Welcome to NAMOAI Digital Private Limited ("NAMOAI," "we," "our," or "us"). We respect your privacy and are committed to protecting your personal data. This privacy policy explains how we collect, use, store, and safeguard your information when you visit our website, engage with our services, or interact with us through any channel.
          </p>
          <p>
            By using our website or services, you consent to the data practices described in this policy. We encourage you to read this document carefully and contact us if you have any questions.
          </p>
        </div>

        {/* 2 */}
        <div className="legal-section">
          <span className="legal-section-number">Section 02</span>
          <h2>Data We Collect</h2>
          <p>
            We may collect, use, store, and transfer different kinds of personal data about you, which we have grouped as follows:
          </p>
          <ul>
            <li><strong>Identity Data</strong> — includes first name, last name, username, or similar identifier.</li>
            <li><strong>Contact Data</strong> — includes email address, telephone numbers, and mailing address.</li>
            <li><strong>Technical Data</strong> — includes internet protocol (IP) address, browser type and version, time zone setting and location, browser plug-in types and versions, operating system and platform, and other technology on the devices you use to access this website.</li>
            <li><strong>Usage Data</strong> — includes information about how you use our website, products, and services.</li>
            <li><strong>Marketing Data</strong> — includes your preferences in receiving marketing communications from us and our partners.</li>
          </ul>
        </div>

        {/* 3 */}
        <div className="legal-section">
          <span className="legal-section-number">Section 03</span>
          <h2>How We Use Your Data</h2>
          <p>
            We will only use your personal data when the law allows us to. Most commonly, we will use your personal data in the following circumstances:
          </p>
          <ul>
            <li>Where we need to perform the contract we are about to enter into or have entered into with you.</li>
            <li>Where it is necessary for our legitimate interests (or those of a third party) and your interests and fundamental rights do not override those interests.</li>
            <li>Where we need to comply with a legal obligation.</li>
            <li>To provide and improve our services, personalize your experience, and respond to your inquiries.</li>
            <li>To send you service-related communications and, with your consent, marketing communications.</li>
          </ul>
        </div>

        {/* 4 */}
        <div className="legal-section">
          <span className="legal-section-number">Section 04</span>
          <h2>Data Security</h2>
          <p>
            We have implemented appropriate technical and organizational security measures to protect your personal data against unauthorized access, alteration, disclosure, or destruction. These measures include encryption, secure server infrastructure, and regular security assessments.
          </p>
          <div className="legal-note">
            <strong>Note:</strong> While we strive to use commercially acceptable means to protect your personal data, no method of transmission over the Internet or electronic storage is 100% secure. We cannot guarantee absolute security.
          </div>
        </div>

        {/* 5 */}
        <div className="legal-section">
          <span className="legal-section-number">Section 05</span>
          <h2>Cookies & Tracking</h2>
          <p>
            Our website may use cookies and similar tracking technologies to enhance your browsing experience, analyze site traffic, and understand user behavior. You can control cookie preferences through your browser settings.
          </p>
          <ul>
            <li><strong>Essential Cookies</strong> — necessary for the website to function properly.</li>
            <li><strong>Analytics Cookies</strong> — help us understand how visitors interact with our site.</li>
            <li><strong>Marketing Cookies</strong> — used to deliver relevant advertisements and track campaign effectiveness.</li>
          </ul>
        </div>

        {/* 6 */}
        <div className="legal-section">
          <span className="legal-section-number">Section 06</span>
          <h2>Third-Party Sharing</h2>
          <p>
            We do not sell your personal data to third parties. We may share your information with trusted service providers who assist us in operating our website, conducting our business, or servicing you, provided that those parties agree to keep this information confidential.
          </p>
          <p>
            We may also disclose your information when required by law, to enforce our site policies, or to protect our or others' rights, property, or safety.
          </p>
        </div>

        {/* 7 */}
        <div className="legal-section">
          <span className="legal-section-number">Section 07</span>
          <h2>Your Rights</h2>
          <p>
            Under applicable data protection laws, you have the following rights regarding your personal data:
          </p>
          <ul>
            <li><strong>Right of Access</strong> — request copies of your personal data.</li>
            <li><strong>Right to Rectification</strong> — request correction of inaccurate or incomplete data.</li>
            <li><strong>Right to Erasure</strong> — request deletion of your personal data under certain conditions.</li>
            <li><strong>Right to Restrict Processing</strong> — request that we limit the processing of your personal data.</li>
            <li><strong>Right to Data Portability</strong> — request transfer of your data to another organization.</li>
            <li><strong>Right to Object</strong> — object to our processing of your personal data.</li>
          </ul>
          <p>
            To exercise any of these rights, please contact us using the details provided below. We will respond to your request within 30 days.
          </p>
        </div>

        {/* 8 */}
        <div className="legal-section">
          <span className="legal-section-number">Section 08</span>
          <h2>Contact Us</h2>
          <p>
            If you have any questions about this privacy policy, our data practices, or would like to exercise your rights, please contact us at:
          </p>
          <ul>
            <li><strong>Email:</strong> <a href="mailto:digitalnamoai@gmail.com">digitalnamoai@gmail.com</a></li>
            <li><strong>Phone:</strong> <a href="https://wa.me/919579057085" target="_blank" rel="noopener noreferrer">+91 95790 57085</a></li>
            <li><strong>Location:</strong> Maharashtra, India</li>
          </ul>
        </div>

        {/* Contact CTA */}
        <div className="legal-contact-cta">
          <h3>Have Questions About Your Privacy?</h3>
          <p>Our team is here to address any concerns about how we handle your data.</p>
          <div className="legal-contact-links">
            <a href="mailto:digitalnamoai@gmail.com">✉️ Email Us</a>
            <a href="https://wa.me/919579057085" target="_blank" rel="noopener noreferrer">💬 WhatsApp</a>
          </div>
        </div>

      </div>
    </div>
  );
}

import React from "react";
import "./Legal.css";

export default function RefundPolicy() {
  return (
    <div className="legal-page">
      {/* ── Hero ── */}
      <section className="legal-hero">
        <h1>
          Refund &amp; <span className="text-gradient">Cancellation Policy</span>
        </h1>
        <p className="legal-subtitle">
          At NAMOAI Digital Private Limited, we are committed to delivering high-quality digital solutions and professional services.
        </p>
        <span className="legal-effective-date">Effective Date: 08 June 2026</span>
      </section>

      {/* ── Content ── */}
      <div className="legal-content-wrapper">
        {/* Introduction */}
        <section className="legal-section">
          <h2>Welcome to NAMOAI Digital Private Limited</h2>
          <p>
            At NAMOAI Digital Private Limited (“Company”, “We”, “Us”, or “Our”), we are committed to
            delivering high-quality digital solutions and professional services. This Refund &amp; Cancellation
            Policy outlines the terms governing refunds, cancellations, and payment disputes related to our services.
          </p>
          <p>
            By purchasing, subscribing to, or using any service offered by NAMOAI Digital Private Limited,
            you acknowledge that you have read, understood, and agreed to this Refund &amp; Cancellation Policy.
          </p>
        </section>

        {/* Section 01 — Scope of Policy */}
        <section className="legal-section">
          <span className="legal-section-number">Section 01</span>
          <h2>Scope of Policy</h2>
          <p>
            This policy applies to all services offered by NAMOAI Digital Private Limited, including but not limited to:
          </p>
          <ul>
            <li>Website Development</li>
            <li>Mobile Application Development</li>
            <li>Software Development</li>
            <li>Digital Marketing Services</li>
            <li>Search Engine Optimization (SEO)</li>
            <li>Social Media Marketing</li>
            <li>Branding &amp; Graphic Design</li>
            <li>AI Automation Solutions</li>
            <li>WhatsApp Automation</li>
            <li>Cloud Solutions</li>
            <li>Business Consulting</li>
            <li>Maintenance &amp; Support Services</li>
            <li>Custom Technology Solutions</li>
          </ul>
        </section>

        {/* Section 02 — Advance Payments */}
        <section className="legal-section">
          <span className="legal-section-number">Section 02</span>
          <h2>Advance Payments</h2>
          <p>
            All advance payments made to NAMOAI Digital Private Limited are intended to reserve project resources, manpower, infrastructure, and timelines.
          </p>
          <p>
            Once project planning, research, design, development, consultation, campaign setup, or service execution has commenced, advance payments become non-refundable.
          </p>
          <div className="legal-note">
            <strong>📌 Note:</strong> Clients are advised to carefully review all proposals, quotations, agreements, and project requirements before making payment.
          </div>
        </section>

        {/* Section 03 — Refund Eligibility */}
        <section className="legal-section">
          <span className="legal-section-number">Section 03</span>
          <h2>Refund Eligibility</h2>
          <p>
            Refund requests may be considered under the following circumstances:
          </p>
          <ul>
            <li><strong>Duplicate Payment</strong> — Duplicate payment made by the client.</li>
            <li><strong>No Work Commenced</strong> — Payment processed successfully but project work has not commenced.</li>
            <li><strong>Operational Limits</strong> — Service cannot be delivered due to internal operational limitations of the Company.</li>
            <li><strong>48-Hour Window</strong> — Refund request submitted within 48 hours of payment and before work commencement.</li>
          </ul>
          <p>
            All approved refunds shall be processed within <strong>7–15 business days</strong> through the original payment method.
          </p>
        </section>

        {/* Section 04 — Non-Refundable Services */}
        <section className="legal-section">
          <span className="legal-section-number">Section 04</span>
          <h2>Non-Refundable Services</h2>
          <p>
            The following payments are strictly non-refundable:
          </p>
          <ul>
            <li>Website Development Charges</li>
            <li>Mobile Application Development Charges</li>
            <li>Software Development Charges</li>
            <li>Digital Marketing Fees</li>
            <li>SEO Service Fees</li>
            <li>Social Media Marketing Fees</li>
            <li>Branding and Design Charges</li>
            <li>Consultation and Strategy Fees</li>
            <li>AI Automation Setup Fees</li>
            <li>WhatsApp Automation Setup Fees</li>
            <li>Training and Onboarding Fees</li>
            <li>Maintenance and Support Fees already utilized</li>
            <li>Custom Development Projects</li>
          </ul>
          <p>
            No refund shall be issued for completed, partially completed, approved, or delivered work.
          </p>
        </section>

        {/* Section 05 — Third-Party Services and Expenses */}
        <section className="legal-section">
          <span className="legal-section-number">Section 05</span>
          <h2>Third-Party Services and Expenses</h2>
          <p>
            The following charges are non-refundable under any circumstances:
          </p>
          <ul>
            <li>Domain Registration Fees</li>
            <li>Web Hosting Charges</li>
            <li>Cloud Hosting Charges</li>
            <li>AWS, Azure, Google Cloud Charges</li>
            <li>API Subscription Charges</li>
            <li>Software License Fees</li>
            <li>SSL Certificate Fees</li>
            <li>Google Ads Spend</li>
            <li>Meta Ads Spend</li>
            <li>Third-Party Software Subscriptions</li>
            <li>Payment Gateway Charges</li>
          </ul>
          <div className="legal-warning">
            <strong>⚠️ Note:</strong> These costs are paid directly to external providers and cannot be recovered by NAMOAI Digital Private Limited.
          </div>
        </section>

        {/* Section 06 — Project Cancellation by Client */}
        <section className="legal-section">
          <span className="legal-section-number">Section 06</span>
          <h2>Project Cancellation by Client</h2>
          <p>
            <strong>Before Project Commencement:</strong> Clients may request project cancellation before work begins. Any approved refund may be subject to deductions for administrative, banking, and payment processing charges.
          </p>
          <p>
            <strong>After Project Commencement:</strong> If a client cancels a project after work has started:
          </p>
          <ul>
            <li>No refund shall be provided for completed milestones.</li>
            <li>Payments already received shall remain non-refundable.</li>
            <li>Outstanding invoices for completed work must be paid in full.</li>
            <li>Deliverables completed up to the cancellation date may be provided at the Company’s discretion.</li>
          </ul>
        </section>

        {/* Section 07 — Subscription and Recurring Services */}
        <section className="legal-section">
          <span className="legal-section-number">Section 07</span>
          <h2>Subscription and Recurring Services</h2>
          <p>
            For recurring monthly, quarterly, or annual services:
          </p>
          <ul>
            <li>Clients may cancel future renewals by providing at least 15 days written notice before the next billing cycle.</li>
            <li>No refund shall be issued for the current active billing period.</li>
            <li>Services shall continue until the end of the paid term.</li>
          </ul>
        </section>

        {/* Section 08 — Marketing Performance Disclaimer */}
        <section className="legal-section">
          <span className="legal-section-number">Section 08</span>
          <h2>Marketing Performance Disclaimer</h2>
          <p>
            NAMOAI Digital Private Limited does not guarantee:
          </p>
          <ul>
            <li>Specific sales figures</li>
            <li>Revenue growth</li>
            <li>Search engine rankings</li>
            <li>Lead generation volumes</li>
            <li>Advertisement performance</li>
            <li>Social media engagement metrics</li>
          </ul>
          <p>
            Marketing and business results depend on multiple external factors beyond the Company’s control. Therefore, dissatisfaction with campaign performance shall not be considered a valid reason for a refund.
          </p>
        </section>

        {/* Section 09 — Chargebacks and Payment Disputes */}
        <section className="legal-section">
          <span className="legal-section-number">Section 09</span>
          <h2>Chargebacks and Payment Disputes</h2>
          <p>
            Clients agree to contact NAMOAI Digital Private Limited before initiating any chargeback or payment dispute.
          </p>
          <p>
            Unauthorized chargebacks may result in:
          </p>
          <ul>
            <li>Immediate suspension of services</li>
            <li>Project termination</li>
            <li>Recovery proceedings for outstanding amounts</li>
            <li>Legal action where applicable</li>
          </ul>
        </section>

        {/* Section 10 — Exceptional Circumstances */}
        <section className="legal-section">
          <span className="legal-section-number">Section 10</span>
          <h2>Exceptional Circumstances</h2>
          <p>
            Refund requests not specifically covered under this policy may be reviewed on a case-by-case basis at the sole discretion of NAMOAI Digital Private Limited. The Company’s decision regarding any refund request shall be final and binding.
          </p>
        </section>

        {/* Section 11 — Limitation of Liability */}
        <section className="legal-section">
          <span className="legal-section-number">Section 11</span>
          <h2>Limitation of Liability</h2>
          <p>
            Under no circumstances shall NAMOAI Digital Private Limited be liable for indirect, incidental, consequential, or special damages arising from the use of our services.
          </p>
          <p>
            The Company’s maximum liability shall not exceed the amount paid by the client for the specific service in dispute.
          </p>
        </section>

        {/* Section 12 — Contact Information */}
        <section className="legal-section">
          <span className="legal-section-number">Section 12</span>
          <h2>Contact Information</h2>
          <div className="support-info-row">
            <div className="support-info-item">
              <span className="info-label">Email</span> <br />
              <span className="info-value">digitalnamoai@gmail.com</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">Website</span> <br />
              <span className="info-value">www.namoaidigital.in</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">Company</span> <br />
              <span className="info-value">NAMOAI Digital Private Limited</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">Status</span> <br />
              <span className="info-value">DPIIT Recognized Startup</span>
            </div>
          </div>
          <p className="muted" style={{ textAlign: "center", marginTop: "20px", fontSize: "14px" }}>
            NAMOAI Digital Private Limited | Structured Execution. Scalable Growth.
          </p>
        </section>
      </div>

      {/* ── Contact CTA ── */}
      <section className="legal-contact-cta">
        <h2>Have Questions?</h2>
        <p>
          By making a payment, purchasing a service, or entering into a business relationship with NAMOAI Digital Private Limited, you acknowledge that you have read, understood, and agreed to this Refund &amp; Cancellation Policy.
        </p>
        <div className="legal-contact-links">
          <a href="mailto:digitalnamoai@gmail.com">✉️ Email Us</a>
          <a href="https://www.namoaidigital.in" target="_blank" rel="noopener noreferrer">🌐 Visit Website</a>
        </div>
      </section>
    </div>
  );
}

import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import ServicePricingModal from "../components/ServicePricingModal";
import useSEO from "../hooks/useSEO";
import "./Services.css";

const services = [
  {
    n: "01",
    t: "Web & App Development",
    d: "Custom websites, web applications, and mobile apps built for performance, scalability, and business growth.",
     serviceKey: "webDevelopment",
    points: [
      "Business Websites",
      "E-Commerce Platforms",
      "Custom Web Apps",
      "Android Apps",
      "iOS Apps",
      "Cross-Platform Apps",
    ],
    icon: (
      <svg
        viewBox="0 0 24 24"
        width="20"
        height="20"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <polyline points="16 18 22 12 16 6" />
        <polyline points="8 6 2 12 8 18" />
      </svg>
    ),
  },

  {
    n: "02",
    t: "AI Automation Solutions",
    d: "Intelligent automation systems that streamline operations, improve efficiency, and reduce manual work.",
     serviceKey: "aiAutomation",
    points: [
      "AI Chatbots",
      "Workflow Automation",
      "CRM Integration",
      "Lead Automation",
      "Business Process Automation",
      "Custom AI Solutions",
    ],
    icon: (
      <svg
        viewBox="0 0 24 24"
        width="20"
        height="20"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <rect x="7" y="7" width="10" height="10" rx="2" />
        <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
        <path d="M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2" />
      </svg>
    ),
  },

  {
    n: "03",
    t: "Business Growth & Consulting",
    d: "Strategic consulting and growth-focused solutions designed to help businesses scale faster.",
    serviceKey: "consulting", 
    points: [
      "Growth Strategy",
      "Business Consulting",
      "Sales Funnel Design",
      "Market Research",
      "Startup Guidance",
      "Digital Transformation",
    ],
    icon: (
      <svg
        viewBox="0 0 24 24"
        width="20"
        height="20"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <polyline points="3 17 9 11 13 15 21 7" />
        <polyline points="14 7 21 7 21 14" />
      </svg>
    ),
  },

  {
    n: "04",
    t: "Performance Marketing",
    d: "Data-driven advertising campaigns optimized for leads, conversions, and measurable ROI.",
        serviceKey: "performanceMarketing",
    points: [
      "Meta Ads",
      "Google Ads",
      "Lead Generation",
      "Conversion Optimization",
      "Retargeting Campaigns",
      "Analytics & Reporting",
    ],
    icon: (
      <svg
        viewBox="0 0 24 24"
        width="20"
        height="20"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <circle cx="12" cy="12" r="8" />
        <circle cx="12" cy="12" r="4" />
        <circle cx="12" cy="12" r="1" fill="currentColor" />
      </svg>
    ),
  },

  {
    n: "05",
    t: "Digital Marketing",
    d: "Comprehensive digital marketing strategies that increase visibility, engagement, and customer acquisition.",
       serviceKey: "digitalMarketing",
    points: [
      "SEO",
      "Social Media Marketing",
      "Instagram Growth",
      "LinkedIn Marketing",
      "Content Marketing",
      "Email Marketing",
    ],
    icon: (
      <svg
        viewBox="0 0 24 24"
        width="20"
        height="20"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <path d="M3 11h18" />
        <path d="M12 3v18" />
        <circle cx="12" cy="12" r="9" />
      </svg>
    ),
  },

  {
    n: "06",
    t: "Creative Branding Services",
    d: "Premium branding, visual identity, content creation, and creative assets that make brands memorable.",
     serviceKey: "branding",
    points: [
      "Logo Design",
      "Brand Identity",
      "Graphic Design",
      "Social Media Creatives",
      "Video Editing",
      "Content Creation",
    ],
    icon: (
      <svg
        viewBox="0 0 24 24"
        width="20"
        height="20"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <polygon points="12 2 15 9 22 9 17 14 19 22 12 18 5 22 7 14 2 9 9 9 12 2" />
      </svg>
    ),
  },
];
export default function Services() {
  const [selectedKey, setSelectedKey] = useState(null);
  const [modalOpen, setModalOpen]     = useState(false);
  const closeTimeoutRef = useRef(null);

  function openModal(serviceKey) {
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
    setSelectedKey(serviceKey);
    setModalOpen(true);
  }

  function closeModal() {
    setModalOpen(false);
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
    }
    // Delay clearing key so exit animation can finish
    closeTimeoutRef.current = setTimeout(() => {
      setSelectedKey(null);
      closeTimeoutRef.current = null;
    }, 300);
  }

  useEffect(() => {
    // Existing IntersectionObserver scroll-reveal logic unchanged
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) e.target.classList.add("revealed");
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -50px 0px" }
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  useSEO({
    title: "Our Services",
    description: "Explore our premium digital solutions including custom web/app development, AI automation, branding, SEO, performance marketing, and business growth consulting.",
    keywords: "AI solutions, web development, app development, performance marketing, branding, CRM automation, NamoAI Digital services"
  });

  return (
    <div className="services-page page-transition-wrapper">
      {/* PAGE HEADER — unchanged */}
      <section className="page-header">
        <div className="grid-bg" />
        <div className="container">
          <span className="section-label">Our Services</span>
          <h1>Digital Solutions That <span className="text-gradient">Deliver.</span></h1>
          <p>Specialized creative, marketing, and technology services built to help brands scale faster.</p>
        </div>
      </section>

      {/* SERVICES GRID — only change: onClick + cursor:pointer */}
      <section className="section">
        <div className="container services-grid reveal-stagger">
          {services.map((s) => (
            <article
              key={s.n}
              className="svc-card reveal"
              style={{ cursor: "pointer" }}
              onClick={() => openModal(s.serviceKey)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === "Enter" && openModal(s.serviceKey)}
              aria-label={`View ${s.t} pricing`}
            >
              <div className="svc-head">
                <span className="mono-tiny">{s.n}</span>
                <div className="svc-icon">{s.icon}</div>
              </div>
              <h2>{s.t}</h2>
              <p className="muted">{s.d}</p>
              <ul>
                {s.points.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
              <div className="card-footer">
                <span className="view-plans-btn">View Plans →</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* CTA SECTION — unchanged */}
      <section className="section divider-top">
        <div className="container svc-cta reveal">
          <h2 className="section-title">Not sure where to start?</h2>
          <p className="muted" style={{ maxWidth: 520, margin: "16px auto 32px" }}>
            We'll identify the highest-impact strategy for your brand in a quick discovery call.
          </p>
          <Link to="/contact" className="btn btn-primary">Start a Project →</Link>
        </div>
      </section>

      {/* MODAL — mounted once, controlled by state */}
      <ServicePricingModal
        serviceKey={selectedKey}
        isOpen={modalOpen}
        onClose={closeModal}
      />
    </div>
  );
}


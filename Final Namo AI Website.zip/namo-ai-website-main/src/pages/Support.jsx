import React from "react";
import "./Legal.css";

export default function Support() {
  return (
    <div className="legal-page">
      {/* ── Hero ── */}
      <section className="legal-hero">
        <h1>
          Get <span className="text-gradient">Support</span>
        </h1>
        <p className="legal-subtitle">
          At NAMOAI Digital, your success is our priority. Our team is dedicated to providing prompt, professional assistance to keep your business running smoothly.
        </p>
        <span className="legal-effective-date">Support Desk Active</span>
      </section>

      {/* ── Content ── */}
      <div className="legal-content-wrapper">
        {/* Support Channels */}
        <section className="legal-section">
          <span className="legal-section-number">Section 01</span>
          <h2>Support Channels</h2>
          <p>
            We offer multiple channels to ensure you can reach us in the way that's most convenient for you.
          </p>
          <div className="legal-cards-grid">
            <div className="legal-card">
              <div className="legal-card-icon">📧</div>
              <h3>Email Support</h3>
              <p>
                Reach us at <strong>digitalnamoai@gmail.com</strong> for general queries, service requests, and project questions. We respond within 24 hours.
              </p>
            </div>
            <div className="legal-card">
              <div className="legal-card-icon">🔧</div>
              <h3>Technical Support</h3>
              <p>
                Expert assistance for infrastructure, server configuration, hosting management, API integrations, and code troubleshooting.
              </p>
            </div>
            <div className="legal-card">
              <div className="legal-card-icon">🤝</div>
              <h3>Client Assistance</h3>
              <p>
                Dedicated account assistance, project consulting, onboarding guides, and general business collaboration inquiries.
              </p>
            </div>
          </div>
        </section>

        {/* Business Hours */}
        <section className="legal-section">
          <span className="legal-section-number">Section 02</span>
          <h2>Business Hours</h2>
          <p>
            Our support desk operates during the following standard hours. Any queries received outside these hours will be queued and resolved on the next business day.
          </p>
          <div className="support-info-row">
            <div className="support-info-item">
              <span className="info-label">Working Days</span>  <br />
              <span className="info-value">Monday – Saturday</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">Working Hours</span> <br />
              <span className="info-value">10:00 AM – 7:00 PM IST</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">Emergency Support</span> <br />
              <span className="info-value">Available for critical outages</span>
            </div>
          </div>
        </section>

        {/* Response Time Information */}
        <section className="legal-section">
          <span className="legal-section-number">Section 03</span>
          <h2>Response Time Information</h2>
          <p>
            We prioritize issues based on severity to ensure critical infrastructure disruptions are addressed with urgency:
          </p>
          <div className="support-info-row">
            <div className="support-info-item">
              <span className="info-label">Critical Issues</span> <br />
              <span className="info-value">Within 4 Hours</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">Technical Issues</span>  <br />
              <span className="info-value">Within 12 Hours</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">General Queries</span>  <br />
              <span className="info-value">Within 24 Hours</span>
            </div>
          </div>
          <div className="legal-note">
            <strong>📌 Note:</strong> Our targets apply to working hours (IST). Outages, server crashes, or database connection errors are escalated automatically for immediate resolution.
          </div>
        </section>

        {/* Support Contact Information */}
        <section className="legal-section">
          <span className="legal-section-number">Section 04</span>
          <h2>Support Contact Details</h2>
          <p>
            For official support tickets, consulting requests, or partnership inquiries:
          </p>
          <div className="support-info-row">
            <div className="support-info-item">
              <span className="info-label">Email Support</span> <br />
              <span className="info-value">digitalnamoai@gmail.com</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">Official Website</span>  <br />
              <span className="info-value">www.namoaidigital.in</span>
            </div>
            <div className="support-info-item">
              <span className="info-label">WhatsApp Helpline</span> <br />
              <span className="info-value">+91 95790 57085</span>
            </div>
          </div>
        </section>
      </div>

      {/* ── Contact CTA ── */}
      <section className="legal-contact-cta">
        <h2>Need Immediate Assistance?</h2>
        <p>
          Our team is here to help. Reach out directly via email or visit our website to start a support request.
        </p>
        <div className="legal-contact-links">
          <a href="mailto:digitalnamoai@gmail.com">✉️ digitalnamoai@gmail.com</a>
          <a href="https://www.namoaidigital.in" target="_blank" rel="noopener noreferrer">🌐 www.namoaidigital.in</a>
          <a href="https://wa.me/919579057085" target="_blank" rel="noopener noreferrer">💬 Chat on WhatsApp</a>
        </div>
      </section>
    </div>
  );
}

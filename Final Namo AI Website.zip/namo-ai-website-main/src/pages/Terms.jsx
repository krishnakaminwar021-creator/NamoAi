import React from "react";
import "./Legal.css";

export default function Terms() {
  return (
    <div className="legal-page">
      {/* ── Hero ── */}
      <section className="legal-hero">
        <h1>
          Terms &amp; <span className="text-gradient">Conditions</span>
        </h1>
        <p className="legal-subtitle">
          These Terms &amp; Conditions outline the rules, responsibilities, and
          legal agreements that govern the relationship between NAMOAI Digital
          Private Limited and its clients. Please read them carefully before
          engaging our services.
        </p>
        <span className="legal-effective-date">Effective: June 1, 2025</span>
      </section>

      {/* ── Content ── */}
      <div className="legal-content-wrapper">
        {/* Section 01 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 01</span>
          <h2>Company Introduction</h2>
          <p>
            NAMOAI Digital Private Limited ("NAMOAI Digital," "we," "us," or
            "our") is a full-service digital solutions company duly registered
            and incorporated under the laws of India, with its principal place
            of operations in the state of Maharashtra. We specialize in
            delivering end-to-end digital transformation services to businesses
            of all scales — from emerging startups to established enterprises.
          </p>
          <p>Our comprehensive suite of services includes, but is not limited to:</p>
          <ul>
            <li>Custom Web Design &amp; Development</li>
            <li>Mobile Application Development (iOS, Android &amp; Cross-Platform)</li>
            <li>Artificial Intelligence &amp; Automation Solutions</li>
            <li>Performance Marketing &amp; Paid Advertising</li>
            <li>Search Engine Optimization (SEO) &amp; Digital Marketing</li>
            <li>Creative Branding &amp; Visual Identity Design</li>
            <li>Business Strategy Consulting &amp; Digital Advisory</li>
          </ul>
          <p>
            Throughout these Terms &amp; Conditions, any individual, business
            entity, or organization that engages NAMOAI Digital for any of the
            aforementioned services shall be referred to as the "Client" or
            "you."
          </p>
        </section>

        {/* Section 02 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 02</span>
          <h2>Acceptance of Services</h2>
          <p>
            By engaging NAMOAI Digital Private Limited for any service —
            whether through a signed proposal, service agreement, purchase
            order, verbal confirmation, email correspondence, or by making any
            payment — the Client expressly acknowledges and agrees to be bound
            by these Terms &amp; Conditions in their entirety.
          </p>
          <p>Acceptance of these terms is deemed to have occurred when the Client:</p>
          <ul>
            <li>
              Signs, digitally approves, or otherwise accepts a project
              proposal, quotation, or scope of work document issued by NAMOAI
              Digital.
            </li>
            <li>
              Makes any payment — whether partial or full — toward services
              rendered or to be rendered by NAMOAI Digital.
            </li>
            <li>
              Provides written or verbal confirmation (including via email,
              messaging platforms, or other electronic communication) to
              proceed with a project or engagement.
            </li>
            <li>
              Continues to use, access, or benefit from deliverables produced
              by NAMOAI Digital after having been presented with these terms.
            </li>
          </ul>
          <div className="legal-note">
            If you do not agree with any provision outlined in these Terms &amp;
            Conditions, please refrain from engaging our services and notify us
            in writing prior to the commencement of any work.
          </div>
        </section>

        {/* Section 03 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 03</span>
          <h2>Service Agreements</h2>
          <p>
            All projects and engagements undertaken by NAMOAI Digital are
            governed by individual Service Agreements, Scope of Work (SOW)
            documents, or formal proposals mutually agreed upon by both
            parties. These documents serve as the definitive reference for the
            terms specific to each engagement and shall be read in conjunction
            with these overarching Terms &amp; Conditions.
          </p>
          <p>
            Each Service Agreement may include, but is not limited to, the
            following components:
          </p>
          <ul>
            <li>
              <strong>Scope of Work:</strong> A detailed description of the
              services to be provided, including specific features,
              functionalities, and deliverables.
            </li>
            <li>
              <strong>Deliverables:</strong> A clear enumeration of all
              tangible outputs the Client can expect upon completion of the
              project.
            </li>
            <li>
              <strong>Project Timelines:</strong> Estimated milestones, review
              periods, and projected completion dates.
            </li>
            <li>
              <strong>Pricing &amp; Cost Breakdown:</strong> A transparent
              breakdown of all costs, including any applicable taxes, platform
              fees, or third-party licensing charges.
            </li>
            <li>
              <strong>Payment Terms:</strong> The schedule and conditions under
              which payments are to be made, including advance deposits,
              milestone payments, and final settlement.
            </li>
            <li>
              <strong>Revision Policy:</strong> The number of revision rounds
              included within the agreed scope and the process for requesting
              additional changes.
            </li>
          </ul>
          <p>
            In the event of any conflict between a specific Service Agreement
            and these general Terms &amp; Conditions, the provisions of the
            Service Agreement shall prevail to the extent of such conflict.
          </p>
        </section>

        {/* Section 04 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 04</span>
          <h2>Pricing &amp; Payments</h2>
          <p>
            All prices quoted by NAMOAI Digital are denominated in Indian
            Rupees (INR) unless explicitly stated otherwise in the relevant
            Service Agreement or proposal. Pricing is subject to the scope of
            work defined at the time of the agreement, and any changes to the
            scope may result in revised pricing.
          </p>
          <p>
            Our standard payment structure operates on a milestone-based
            model, which typically includes:
          </p>
          <ul>
            <li>
              <strong>Advance Payment:</strong> A non-refundable advance of
              30–50% of the total project cost is required before work
              commences. The exact percentage will be specified in the
              respective Service Agreement.
            </li>
            <li>
              <strong>Milestone Payments:</strong> Subsequent payments are tied
              to the completion of predefined project milestones, as outlined
              in the agreed payment schedule.
            </li>
            <li>
              <strong>Final Settlement:</strong> The remaining balance must be
              cleared in full before the final deliverables, source files, or
              deployment credentials are released to the Client.
            </li>
          </ul>
          <p>Accepted payment methods include:</p>
          <ul>
            <li>Bank Transfer (NEFT / RTGS / IMPS)</li>
            <li>UPI Payments</li>
            <li>Online Payment Gateways</li>
            <li>Other methods as mutually agreed upon</li>
          </ul>
          <div className="legal-note">
            Invoices are payable within 7 business days of issuance unless
            otherwise specified. Late payments may attract a penalty of 2% per
            month on the outstanding balance and may result in suspension of
            ongoing work until the account is brought current.
          </div>
        </section>

        {/* Section 05 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 05</span>
          <h2>Project Timelines</h2>
          <p>
            All project timelines, milestones, and estimated delivery dates
            communicated by NAMOAI Digital are provided in good faith and
            represent our best professional estimate based on the defined scope
            of work and the assumption of timely cooperation from the Client.
          </p>
          <p>
            It is expressly understood that timelines are subject to change and
            may be extended without any liability to NAMOAI Digital under the
            following circumstances:
          </p>
          <ul>
            <li>
              Delayed feedback, approvals, or sign-offs from the Client on
              design mockups, prototypes, or development stages.
            </li>
            <li>
              Late provision of required content, assets, imagery, copy, or
              any other materials necessary for project progression.
            </li>
            <li>
              Changes in project scope, additional feature requests, or
              revisions beyond the originally agreed scope of work.
            </li>
            <li>
              Delays in providing access credentials, hosting details, or
              third-party platform authorizations required for implementation.
            </li>
            <li>
              Circumstances classified under the Force Majeure clause of these
              Terms &amp; Conditions.
            </li>
          </ul>
          <p>
            NAMOAI Digital will make reasonable efforts to communicate any
            anticipated delays and work collaboratively with the Client to
            establish revised timelines. However, we shall not be held liable
            for any losses, damages, or inconvenience arising from delays
            attributable to the Client or external factors beyond our
            reasonable control.
          </p>
        </section>

        {/* Section 06 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 06</span>
          <h2>Client Responsibilities</h2>
          <p>
            The successful and timely delivery of any project is a
            collaborative endeavor. The Client acknowledges that their active
            participation and cooperation are essential to the execution of the
            agreed scope of work. The Client agrees to fulfill the following
            responsibilities:
          </p>
          <ul>
            <li>
              Provide timely and constructive feedback on all deliverables,
              mockups, prototypes, and development milestones within the agreed
              review periods.
            </li>
            <li>
              Supply all required content — including but not limited to text,
              images, logos, branding assets, product information, and
              multimedia files — in a timely manner and in the formats
              specified by NAMOAI Digital.
            </li>
            <li>
              Grant necessary access credentials to hosting platforms, domain
              registrars, CMS systems, social media accounts, advertising
              platforms, analytics tools, and any other third-party services
              required for project execution.
            </li>
            <li>
              Designate a single point of contact authorized to provide
              approvals, sign-offs, and decisions on behalf of the Client
              organization.
            </li>
            <li>
              Ensure that all content, materials, and instructions provided to
              NAMOAI Digital are accurate, lawful, and do not infringe upon the
              intellectual property rights of any third party.
            </li>
            <li>
              Communicate any changes in requirements, priorities, or
              expectations promptly and in writing.
            </li>
            <li>
              Complete testing, review, and acceptance of deliverables within
              the stipulated timeframe. Failure to respond within the agreed
              review period may result in deliverables being deemed accepted.
            </li>
          </ul>
        </section>

        {/* Section 07 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 07</span>
          <h2>Intellectual Property Rights</h2>
          <p>
            Upon receipt of full and final payment for the completed project,
            the Client shall receive full ownership rights to the final
            deliverables as defined in the respective Service Agreement. This
            transfer of ownership applies exclusively to the custom work
            created specifically for the Client's project.
          </p>
          <p>
            Notwithstanding the above transfer, the following conditions
            apply:
          </p>
          <ul>
            <li>
              <strong>Portfolio Rights:</strong> NAMOAI Digital retains the
              irrevocable right to showcase the completed work in its
              portfolio, case studies, marketing materials, website, social
              media, and pitch presentations, unless a separate Non-Disclosure
              Agreement (NDA) explicitly restricts such usage.
            </li>
            <li>
              <strong>Pre-existing Intellectual Property:</strong> Any
              proprietary frameworks, libraries, code modules, tools,
              templates, methodologies, or processes developed by NAMOAI
              Digital prior to or independent of the Client's project remain
              the exclusive intellectual property of NAMOAI Digital.
            </li>
            <li>
              <strong>Reusable Components:</strong> Generic, non-client-specific
              code components, design patterns, or functional modules created
              during the project may be reused by NAMOAI Digital in future
              projects.
            </li>
          </ul>
          <div className="legal-note">
            Certain deliverables may incorporate third-party software,
            libraries, fonts, plugins, or assets that are subject to their own
            licensing terms (e.g., open-source licenses, commercial licenses).
            The Client is responsible for complying with all applicable
            third-party license agreements. NAMOAI Digital will provide
            documentation of any such third-party components upon request.
          </div>
        </section>

        {/* Section 08 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 08</span>
          <h2>Third-Party Services</h2>
          <p>
            In the course of delivering our services, NAMOAI Digital may
            utilize, integrate, or recommend third-party tools, platforms,
            APIs, software, and service providers as deemed necessary for
            optimal project execution. These may include, but are not limited
            to:
          </p>
          <ul>
            <li>Web hosting and cloud infrastructure providers</li>
            <li>Domain registration and DNS management services</li>
            <li>Advertising platforms (Google Ads, Meta Ads, LinkedIn Ads, etc.)</li>
            <li>Analytics and tracking tools (Google Analytics, etc.)</li>
            <li>Payment gateway integrations</li>
            <li>Email marketing and CRM platforms</li>
            <li>AI and machine learning APIs</li>
            <li>Content delivery networks (CDNs) and security services</li>
          </ul>
          <p>
            NAMOAI Digital is not liable for any service disruptions,
            downtime, data breaches, policy changes, pricing modifications, or
            terms of service alterations imposed by any third-party provider.
            The Client acknowledges that the use of third-party services is
            subject to the respective provider's own terms, conditions, and
            privacy policies.
          </p>
          <p>
            Any costs associated with third-party services — including
            licensing fees, subscription charges, platform fees, or ad spend —
            are the responsibility of the Client unless explicitly included in
            the project pricing by NAMOAI Digital.
          </p>
        </section>

        {/* Section 09 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 09</span>
          <h2>Marketing Disclaimer</h2>
          <p>
            NAMOAI Digital provides professional digital marketing, search
            engine optimization (SEO), pay-per-click (PPC) advertising, social
            media marketing, and related performance marketing services based
            on industry best practices, data-driven strategies, and our
            accumulated expertise.
          </p>
          <p>
            However, marketing outcomes are inherently influenced by a
            multitude of external factors beyond NAMOAI Digital's control,
            including but not limited to:
          </p>
          <ul>
            <li>Search engine algorithm updates and policy changes</li>
            <li>Competitive landscape and market saturation</li>
            <li>Advertising platform policy modifications</li>
            <li>Consumer behavior trends and seasonal fluctuations</li>
            <li>Industry-specific regulatory changes</li>
            <li>Quality and competitiveness of the Client's product or service offering</li>
            <li>Economic conditions and market dynamics</li>
          </ul>
          <div className="legal-warning">
            NAMOAI Digital does not guarantee specific results, including but
            not limited to: search engine rankings, website traffic volumes,
            lead generation numbers, conversion rates, return on investment
            (ROI), or revenue figures. All projections, forecasts, and
            performance estimates shared during consultations or proposals are
            indicative and based on historical data and industry benchmarks —
            they do not constitute binding commitments or guarantees of future
            performance.
          </div>
        </section>

        {/* Section 10 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 10</span>
          <h2>Confidentiality</h2>
          <p>
            Both NAMOAI Digital and the Client mutually agree to maintain
            strict confidentiality regarding all proprietary, sensitive, and
            non-public information exchanged during the course of the
            engagement. This obligation of confidentiality shall survive the
            termination or completion of the project.
          </p>
          <p>Confidential information includes, but is not limited to:</p>
          <ul>
            <li>Business strategies, plans, and financial information</li>
            <li>Trade secrets, proprietary processes, and methodologies</li>
            <li>Customer data, user databases, and contact lists</li>
            <li>Technical specifications, source code, and system architecture</li>
            <li>Marketing strategies, campaign data, and analytics insights</li>
            <li>Pricing structures, contractual terms, and commercial agreements</li>
            <li>Any information explicitly marked or communicated as confidential</li>
          </ul>
          <p>
            Neither party shall disclose, reproduce, or use the other party's
            confidential information for any purpose other than the fulfillment
            of the agreed services, except with prior written consent or as
            required by applicable law, regulation, or court order.
          </p>
        </section>

        {/* Section 11 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 11</span>
          <h2>Limitation of Liability</h2>
          <p>
            To the maximum extent permitted by applicable law, NAMOAI Digital
            Private Limited's total aggregate liability arising out of or in
            connection with any service, project, or engagement shall not
            exceed the total fees actually paid by the Client to NAMOAI
            Digital for the specific service or project giving rise to the
            claim.
          </p>
          <p>
            Under no circumstances shall NAMOAI Digital be liable for any of
            the following, whether arising from contract, tort, negligence,
            strict liability, or otherwise:
          </p>
          <ul>
            <li>Indirect, incidental, special, or consequential damages</li>
            <li>Loss of profits, revenue, business, or anticipated savings</li>
            <li>Loss of data, goodwill, or reputation</li>
            <li>Business interruption or downtime costs</li>
            <li>
              Damages arising from the Client's failure to fulfill their
              responsibilities as outlined in these terms
            </li>
            <li>
              Damages resulting from unauthorized modifications to
              deliverables made by the Client or third parties after handover
            </li>
          </ul>
          <div className="legal-note">
            This limitation of liability applies regardless of whether NAMOAI
            Digital has been advised of the possibility of such damages. The
            Client acknowledges that the pricing of our services reflects this
            allocation of risk.
          </div>
        </section>

        {/* Section 12 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 12</span>
          <h2>Refunds &amp; Cancellations</h2>
          <p>
            Refund eligibility, cancellation procedures, and related
            provisions are governed by our comprehensive{" "}
            <strong>Refund &amp; Cancellation Policy</strong>, which is
            available as a separate document on our website and forms an
            integral part of these Terms &amp; Conditions.
          </p>
          <p>A brief summary of the key provisions is as follows:</p>
          <ul>
            <li>
              The initial advance payment is non-refundable, as it covers
              project setup, resource allocation, and preliminary work.
            </li>
            <li>
              Refund eligibility for subsequent milestone payments depends on
              the stage of project completion at the time of the cancellation
              request.
            </li>
            <li>
              Cancellation requests must be submitted in writing via email to
              our official communication channels.
            </li>
            <li>
              Work completed up to the point of cancellation remains the
              property of NAMOAI Digital unless full payment for that phase has
              been received.
            </li>
            <li>
              Custom or bespoke work that has been completed and approved is
              non-refundable.
            </li>
          </ul>
          <p>
            For the complete and binding terms regarding refunds and
            cancellations, please refer to our dedicated Refund &amp;
            Cancellation Policy page.
          </p>
        </section>

        {/* Section 13 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 13</span>
          <h2>Termination of Services</h2>
          <p>
            Either party may terminate an ongoing engagement by providing a
            minimum of fifteen (15) calendar days' prior written notice to the
            other party. Written notice may be delivered via email to the
            official contact addresses on record.
          </p>
          <p>Upon termination of services, the following provisions shall apply:</p>
          <ul>
            <li>
              <strong>Payment for Completed Work:</strong> The Client shall be
              liable to pay for all work completed up to the effective date of
              termination, including any approved milestones and work-in-progress
              proportional to the effort expended.
            </li>
            <li>
              <strong>Deliverable Handover:</strong> Upon receipt of all
              outstanding payments, NAMOAI Digital shall provide the Client
              with all completed deliverables in their current state.
              Work-in-progress deliverables will be handed over in their
              as-is condition.
            </li>
            <li>
              <strong>Advance Payments:</strong> Any non-refundable advance
              payments already made shall not be returned, consistent with our
              Refund &amp; Cancellation Policy.
            </li>
            <li>
              <strong>Confidentiality Obligations:</strong> The confidentiality
              obligations outlined in Section 10 shall survive the termination
              of the engagement.
            </li>
            <li>
              <strong>Third-Party Commitments:</strong> The Client shall
              remain responsible for any third-party costs, subscriptions, or
              commitments incurred on their behalf during the engagement.
            </li>
          </ul>
          <p>
            NAMOAI Digital reserves the right to terminate services immediately
            and without notice in cases of non-payment, breach of these terms,
            fraudulent activity, or any conduct that is illegal or harmful to
            NAMOAI Digital's reputation or operations.
          </p>
        </section>

        {/* Section 14 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 14</span>
          <h2>Indemnification</h2>
          <p>
            The Client agrees to indemnify, defend, and hold harmless NAMOAI
            Digital Private Limited, its directors, officers, employees,
            agents, and affiliates from and against any and all claims,
            liabilities, damages, losses, costs, and expenses (including
            reasonable legal fees) arising out of or in connection with:
          </p>
          <ul>
            <li>
              Any content, materials, data, images, or instructions provided
              by the Client that infringe upon the intellectual property
              rights, privacy rights, or any other legal rights of any third
              party.
            </li>
            <li>
              The Client's use of deliverables in a manner that violates
              applicable laws, regulations, or third-party rights.
            </li>
            <li>
              Any breach by the Client of their representations, warranties,
              or obligations under these Terms &amp; Conditions or the
              applicable Service Agreement.
            </li>
            <li>
              Any claims arising from the Client's business operations,
              products, or services that incorporate deliverables created by
              NAMOAI Digital.
            </li>
          </ul>
          <p>
            This indemnification obligation shall survive the completion or
            termination of the engagement between the parties.
          </p>
        </section>

        {/* Section 15 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 15</span>
          <h2>Force Majeure</h2>
          <p>
            Neither NAMOAI Digital nor the Client shall be held liable for any
            delay, failure, or interruption in the performance of their
            respective obligations under these Terms &amp; Conditions or any
            Service Agreement, to the extent that such delay or failure is
            caused by events or circumstances beyond the reasonable control of
            the affected party.
          </p>
          <p>Force majeure events include, but are not limited to:</p>
          <ul>
            <li>Natural disasters (earthquakes, floods, hurricanes, etc.)</li>
            <li>Epidemics, pandemics, or public health emergencies</li>
            <li>Acts of war, terrorism, civil unrest, or armed conflict</li>
            <li>Government actions, sanctions, embargoes, or regulatory changes</li>
            <li>Nationwide or regional internet outages or infrastructure failures</li>
            <li>Power outages, server failures, or cyberattacks beyond reasonable prevention</li>
            <li>Labour strikes, lockouts, or industrial disputes</li>
          </ul>
          <p>
            The affected party shall notify the other party of the force
            majeure event as soon as reasonably practicable and shall use
            commercially reasonable efforts to mitigate its effects. If a
            force majeure event continues for a period exceeding sixty (60)
            calendar days, either party may terminate the affected engagement
            by providing written notice.
          </p>
        </section>

        {/* Section 16 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 16</span>
          <h2>Governing Law &amp; Jurisdiction</h2>
          <p>
            These Terms &amp; Conditions, together with all Service Agreements
            and related documents, shall be governed by, construed, and
            interpreted in accordance with the laws of the Republic of India,
            without regard to its conflict of law principles.
          </p>
          <p>
            Any dispute, controversy, or claim arising out of or in connection
            with these terms, or the breach, termination, or invalidity
            thereof, shall be subject to the exclusive jurisdiction of the
            competent courts located in the state of Maharashtra, India.
          </p>
          <p>
            Before resorting to formal litigation, both parties agree to
            attempt to resolve any dispute through good-faith negotiation and,
            if necessary, mediation. If the dispute remains unresolved after a
            period of thirty (30) calendar days of negotiation, either party
            may initiate legal proceedings in the designated courts.
          </p>
        </section>

        {/* Section 17 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 17</span>
          <h2>Amendments</h2>
          <p>
            NAMOAI Digital Private Limited reserves the right to modify,
            update, or revise these Terms &amp; Conditions at any time, at its
            sole discretion, to reflect changes in our services, business
            practices, legal requirements, or industry standards.
          </p>
          <p>
            In the event of material changes to these terms, NAMOAI Digital
            will notify affected clients through one or more of the following
            channels:
          </p>
          <ul>
            <li>Email notification to the registered email address on file</li>
            <li>Prominent notice on our official website</li>
            <li>Direct communication through the designated project manager</li>
          </ul>
          <p>
            The updated terms will include a revised "Effective Date" at the
            top of the document. The Client's continued engagement with NAMOAI
            Digital after being notified of the changes — or after the revised
            effective date, whichever is later — shall constitute the Client's
            acceptance of the updated Terms &amp; Conditions.
          </p>
          <div className="legal-note">
            We encourage all clients to periodically review these Terms &amp;
            Conditions to stay informed of any updates. The most current
            version will always be accessible on our website.
          </div>
        </section>

        {/* Section 18 */}
        <section className="legal-section">
          <span className="legal-section-number">Section 18</span>
          <h2>Contact Information</h2>
          <p>
            For any questions, concerns, or inquiries regarding these Terms
            &amp; Conditions, or any other matter related to our services,
            please do not hesitate to reach out to us through any of the
            following channels:
          </p>
          <ul>
            <li>
              <strong>Email:</strong> digitalnamoai@gmail.com
            </li>
            <li>
              <strong>Phone / WhatsApp:</strong> +91 95790 57085
            </li>
            <li>
              <strong>Location:</strong> Maharashtra, India
            </li>
          </ul>
          <p>
            Our team is available to assist you during standard business hours
            and will endeavor to respond to all inquiries within 24–48 business
            hours.
          </p>
        </section>
      </div>

      {/* ── Contact CTA ── */}
      <section className="legal-contact-cta">
        <h2>Have Questions About Our Terms?</h2>
        <p>
          We believe in transparency and are always happy to clarify any aspect
          of our terms. Reach out to our team and we'll respond promptly.
        </p>
        <div className="legal-contact-links">
          <a href="mailto:digitalnamoai@gmail.com">✉ digitalnamoai@gmail.com</a>
          <a
            href="https://wa.me/919579057085"
            target="_blank"
            rel="noopener noreferrer"
          >
            💬 WhatsApp Us
          </a>
        </div>
      </section>
    </div>
  );
}

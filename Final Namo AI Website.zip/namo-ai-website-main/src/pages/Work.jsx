import { useEffect } from "react";
import { Link } from "react-router-dom";
import useSEO from "../hooks/useSEO";
import "./Work.css";

const cases = [
  {
    tag: "Award-Winning HealthTech Innovation",
    name: "AetherDx",
    outcome:
      "Pre-symptomatic health intelligence platform built during a hackathon. Integrated ABDM/ABHA clinical data, AI-powered risk prediction, explainable analytics (SHAP), multilingual healthcare intelligence, and immersive 3D patient visualization. Designed to transform fragmented health records into predictive, actionable insights before symptoms appear.",
    up: "MVP",
    metric: "Healthcare Intelligence",
    from: "Reactive Care",
    to: "Predictive Care",
    badges: [
      "Next.js",
      "Three.js",
      "AI/ML",
      "FHIR",
      "ABDM",
      "SHAP"
    ]
  },

  { 
    tag: "Fintech Startup", 
    name: "Lendr Systems", 
    outcome: "Conversion-engineered onboarding & custom web application.", 
    up: "+312%", 
    metric: "User Registrations Lift", 
    from: "1.4%", 
    to: "5.8%",
    badges: ["Next.js", "Figma", "Branding"]
  },

  { 
    tag: "D2C Cosmetics", 
    name: "Aurae Beauty", 
    outcome: "Full headless e-commerce build and optimized advertising funnel.", 
    up: "4.2x", 
    metric: "Blended ROAS Scale", 
    from: "1.1x", 
    to: "4.6x",
    badges: ["React", "UI/UX Design", "Meta Ads"]
  },

  { 
    tag: "Productivity SaaS", 
    name: "Outline Workspace", 
    outcome: "Polished marketing layout, organic SEO setup, and high-retention video production.", 
    up: "+186%", 
    metric: "Trial-to-Paid Conversion", 
    from: "3.1%", 
    to: "8.9%",
    badges: ["Video Production", "SEO Engine", "Tailwind"]
  },

  { 
    tag: "Health & Wellness", 
    name: "Helix App", 
    outcome: "Intuitive product design system, mobile wireframes, and video promos.", 
    up: "+92%", 
    metric: "First-Week User Retention", 
    from: "23%", 
    to: "44%",
    badges: ["React Native", "Figma", "Mobile UI"]
  },

  { 
    tag: "SaaS Marketplace", 
    name: "Mosaic Platform", 
    outcome: "Aggressive paid search campaigns, lead generation forms, and SEO copywriting.", 
    up: "-41%", 
    metric: "Customer Acquisition Cost", 
    from: "$118", 
    to: "$69",
    badges: ["Google Ads", "Conversion Rate", "SEO Optimization"]
  }
];

const metrics = [
  { v: "300+", l: "Clients Served" },
  { v: "250+", l: "Projects Delivered" },
  { v: "90%", l: "Client Retention" },
  { v: "16", l: "Retainer Accounts" }
];

const portfolioLinks = [
  {
    category: "Developer Portfolio",
    desc:
      "High-performance websites, web applications, and digital platforms built with modern technology stacks.",
    link: "https://linkmaker.in/5cQufw",
    icon: (
      <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <polyline points="16 18 22 12 16 6" />
        <polyline points="8 6 2 12 8 18" />
      </svg>
    ),
  },

  {
    category: "Marketing Portfolio",
    desc:
      "Performance marketing campaigns, SEO strategies, social media growth, paid advertising, and lead generation solutions that drive measurable business results.",
    link: "https://linkmaker.in/n5EIXf",
    icon: (
      <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <circle cx="12" cy="12" r="10" />
        <path d="M12 2v20M2 12h20" />
      </svg>
    ),
  },

  {
    category: "Video Editing Portfolio",
    desc:
      "Cinematic edits, reels, promotional videos, and motion graphics that capture attention and drive engagement.",
    link: "https://linkmaker.in/bkTycC",
    icon: (
      <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <polygon points="23 7 16 12 23 17 23 7" />
        <rect x="1" y="5" width="15" height="14" rx="2" />
      </svg>
    ),
  },

  {
    category: "Graphic Design Portfolio",
    desc:
      "Brand identities, social media creatives, marketing collateral, and visual design systems crafted with precision.",
    link: "https://linkmaker.in/MBtkg3",
    icon: (
      <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="3" y="3" width="18" height="18" rx="2" />
        <circle cx="8.5" cy="8.5" r="1.5" />
        <path d="m21 15-5-5L5 21" />
      </svg>
    ),
  },
];
export default function Work() {
  // Scroll Reveal Observer
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("revealed");
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -50px 0px" }
    );
    
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  useSEO({
    title: "Our Work & Case Studies",
    description: "Explore NamoAI Digital case studies and featured work. Discover how we've built, marketed, and automated for clients globally.",
    keywords: "AetherDx, case studies, Web development portfolio, NamoAI Digital projects, AI automations, growth stories"
  });

  return (
    <div className="work-page page-transition-wrapper">
      <section className="page-header">
        <div className="grid-bg" />
        <div className="container">
          <span className="section-label">Selected work</span>
          <h1>
            Outcomes, <span className="text-gradient">not deliverables.</span>
          </h1>
          <p>A snapshot of recent engagements. Every project shipped in weeks — built to convert from day one.</p>
        </div>
      </section>

      {/* ===== METRICS OVERALL ===== */}
      <section className="section">
        <div className="container metrics-grid reveal-stagger">
          {metrics.map((m) => (
            <div key={m.l} className="metric reveal">
              <div className="metric-v text-gradient">{m.v}</div>
              <div className="metric-l">{m.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ===== PORTFOLIO DIRECTORY CATEGORY CARDS ===== */}
      <section className="section divider-top">
        <div className="container reveal-stagger">
          <div className="reveal" style={{ textAlign: "center", marginBottom: "48px" }}>
            <span className="section-label">Direct Portfolio Portals</span>
            <h2 className="section-title" style={{ margin: "0 auto" }}>Explore Specific Portfolios</h2>
            <p className="muted" style={{ maxWidth: 520, margin: "16px auto 0" }}>
              Explore real-time files, visual drives, and live build links.
            </p>
          </div>

          <div className="portfolio-links">
            {portfolioLinks.map((p, index) => (
              <a
                key={index}
                href={p.link}
                target="_blank"
                rel="noopener noreferrer"
                className="portfolio-link-card glass reveal"
                style={{ "--delay": `${index * 0.1}s` }}
                onClick={() => console.log(`Opened portfolio: ${p.category}`)}
              >
                <div className="portfolio-icon">
                  {p.icon}
                </div>
                <h3>{p.category}</h3>
                <p className="muted">{p.desc}</p>
                <span className="portfolio-arrow">
                  Open Drive Portfolio <span aria-hidden="true">↗</span>
                </span>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CASE STUDIES GRID ===== */}
      <section className="section divider-top">
        <div className="container work-list reveal-stagger">
          {cases.map((c, i) => (
            <article key={c.name} className="work-card glass reveal">
              <div className="work-left">
                <span className="mono-tiny">{String(i + 1).padStart(2, "0")} · {c.tag}</span>
                <h2>{c.name}</h2>
                <p className="muted">{c.outcome}</p>
                <div className="tech-badges-wrap">
                  {c.badges.map((b) => (
                    <span key={b} className="tech-badge">{b}</span>
                  ))}
                </div>
              </div>
              <div className="work-right">
                <div>
                  <div className="mono-tiny">Lift</div>
                  <div className="work-stat text-gradient">{c.up}</div>
                </div>
                <div>
                  <div className="mono-tiny">Metric</div>
                  <div style={{ fontSize: "14px", fontWeight: 500, color: "var(--text)" }}>{c.metric}</div>
                </div>
                <div>
                  <div className="mono-tiny">Before → After</div>
                  <div style={{ fontSize: "14px", fontWeight: 500, color: "var(--text)" }}>
                    <span className="muted">{c.from}</span> → {c.to}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section divider-top">
        <div className="container reveal" style={{ textAlign: "center" }}>
          <h2 className="section-title" style={{ margin: "0 auto" }}>Your story, next.</h2>
          <p className="muted" style={{ maxWidth: 520, margin: "16px auto 32px" }}>
            Tell us about your stage. We'll show you what's possible in 90 days.
          </p>
          <Link to="/contact" className="btn btn-primary">Start a project →</Link>
        </div>
      </section>
    </div>
  );
}
